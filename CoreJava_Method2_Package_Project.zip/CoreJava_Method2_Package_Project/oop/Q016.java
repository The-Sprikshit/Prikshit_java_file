package oop;

abstract class Q016Helper1 {
    abstract double area();
    abstract double perimeter();
}
class Q016Helper2 extends Q016Helper1 {
    double w, h; Q016Helper2(double w, double h) { this.w=w; this.h=h; }
    double area() { return w*h; } double perimeter() { return 2*(w+h); }
}
class Q016Helper3 extends Q016Helper1 {
    double r; Q016Helper3(double r) { this.r=r; }
    double area() { return Math.PI*r*r; } double perimeter() { return 2*Math.PI*r; }
}
class Q016Helper4 extends Q016Helper1 {
    double a,b,c; Q016Helper4(double a,double b,double c) { this.a=a; this.b=b; this.c=c; }
    double area() { double s=perimeter()/2; return Math.sqrt(s*(s-a)*(s-b)*(s-c)); }
    double perimeter() { return a+b+c; }
}
public class Q016 {
    public static void main(String[] args) {
        Q016Helper1[] shapes = {new Q016Helper2(4,3), new Q016Helper3(2), new Q016Helper4(3,4,5)};
        for (Q016Helper1 s : shapes) System.out.println(s.area() + " / " + s.perimeter());
    }
}
