package oop;

class Q024Helper1 {
    double calculate(double radius) { return Math.PI * radius * radius; }
    double calculate(double length, double width) { return length * width; }
}
public class Q024 {
    public static void main(String[] args) {
        Q024Helper1 a = new Q024Helper1();
        System.out.println("Circle: " + a.calculate(3));
        System.out.println("Rectangle: " + a.calculate(4, 5));
    }
}
