package oop;

import java.util.*;
class Q010Helper1 {
    String name, grade; List<String> courses = new ArrayList<>();
    Q010Helper1(String name, String grade) { this.name=name; this.grade=grade; }
    void addCourse(String course) { courses.add(course); }
    void removeCourse(String course) { courses.remove(course); }
}
public class Q010 {
    public static void main(String[] args) {
        Q010Helper1 s = new Q010Helper1("Isha", "A");
        s.addCourse("Java"); s.addCourse("DBMS"); s.removeCourse("DBMS");
        System.out.println(s.name + ": " + s.courses);
    }
}
