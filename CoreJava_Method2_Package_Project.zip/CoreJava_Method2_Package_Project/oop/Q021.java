package oop;

class Q021Helper1 {
    int rollNo; String name;
    Q021Helper1(int rollNo, String name) { this.rollNo=rollNo; this.name=name; }
}
public class Q021 {
    public static void main(String[] args) {
        Q021Helper1 s = new Q021Helper1(101, "Riya");
        System.out.println(s.rollNo + " " + s.name);
    }
}
