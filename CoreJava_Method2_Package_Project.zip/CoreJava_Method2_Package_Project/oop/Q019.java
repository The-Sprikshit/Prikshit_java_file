package oop;

import java.util.*;
class Q019Helper1 {
    List<String> flights = List.of("AB123 Delhi", "CD456 Mumbai");
    List<String> hotels = List.of("City Hotel", "Lake Hotel");
    Set<String> reservations = new HashSet<>();
    List<String> searchFlights(String query) { return flights.stream().filter(x -> x.toLowerCase().contains(query.toLowerCase())).toList(); }
    List<String> searchHotels(String query) { return hotels.stream().filter(x -> x.toLowerCase().contains(query.toLowerCase())).toList(); }
    void book(String reference) { reservations.add(reference); }
    void cancel(String reference) { reservations.remove(reference); }
}
public class Q019 {
    public static void main(String[] args) {
        Q019Helper1 service = new Q019Helper1();
        System.out.println(service.searchFlights("Delhi"));
        service.book("REF100"); service.cancel("REF100");
        System.out.println(service.reservations);
    }
}
