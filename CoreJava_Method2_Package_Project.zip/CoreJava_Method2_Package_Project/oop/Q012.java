package oop;

import java.time.LocalDateTime;
class Q012Helper1 {
    String flightNumber, destination; LocalDateTime departure;
    Q012Helper1(String flightNumber, String destination, LocalDateTime departure) { this.flightNumber=flightNumber; this.destination=destination; this.departure=departure; }
    String status() { return LocalDateTime.now().isAfter(departure) ? "Departure time passed" : "Scheduled"; }
    void delayByMinutes(long minutes) { departure = departure.plusMinutes(minutes); }
}
public class Q012 {
    public static void main(String[] args) {
        Q012Helper1 flight = new Q012Helper1("AB123", "Delhi", LocalDateTime.now().plusHours(2));
        System.out.println(flight.status()); flight.delayByMinutes(30);
        System.out.println(flight.departure);
    }
}
