package oop;

class Q020Helper1 {
    Q020Helper1() { System.out.println("Default-style constructor called"); }
}
public class Q020 {
    public static void main(String[] args) { new Q020Helper1(); }
}
