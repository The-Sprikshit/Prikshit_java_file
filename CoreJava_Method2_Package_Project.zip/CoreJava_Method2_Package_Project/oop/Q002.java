package oop;

class Q002Helper1 {
    private String name, breed;
    Q002Helper1(String name, String breed) { this.name = name; this.breed = breed; }
    void setName(String name) { this.name = name; }
    void setBreed(String breed) { this.breed = breed; }
    String getName() { return name; }
    String getBreed() { return breed; }
}
public class Q002 {
    public static void main(String[] args) {
        Q002Helper1 d1 = new Q002Helper1("Bruno", "Labrador");
        Q002Helper1 d2 = new Q002Helper1("Milo", "Beagle");
        d1.setName("Buddy"); d2.setBreed("Indie");
        System.out.println(d1.getName() + " - " + d1.getBreed());
        System.out.println(d2.getName() + " - " + d2.getBreed());
    }
}
