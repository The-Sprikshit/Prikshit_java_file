package oop;

class Q026Helper1 {
    private String name, country; private int age;
    public String getName() { return name; } public void setName(String name) { this.name=name; }
    public int getAge() { return age; } public void setAge(int age) { if(age<0) throw new IllegalArgumentException(); this.age=age; }
    public String getCountry() { return country; } public void setCountry(String country) { this.country=country; }
}
public class Q026 {
    public static void main(String[] args) {
        Q026Helper1 p = new Q026Helper1(); p.setName("Aman"); p.setAge(20); p.setCountry("India");
        System.out.println(p.getName()+", "+p.getAge()+", "+p.getCountry());
    }
}
