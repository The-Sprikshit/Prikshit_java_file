package oop;

import java.util.*;
class Q017Helper1 {
    String title, director; List<String> actors; List<String> reviews = new ArrayList<>();
    Q017Helper1(String title, String director, List<String> actors) { this.title=title; this.director=director; this.actors=new ArrayList<>(actors); }
    void addReview(String review) { reviews.add(review); }
    List<String> getReviews() { return Collections.unmodifiableList(reviews); }
}
public class Q017 {
    public static void main(String[] args) {
        Q017Helper1 m = new Q017Helper1("Example Film", "A. Director", List.of("Actor One", "Actor Two"));
        m.addReview("Enjoyable story"); System.out.println(m.getReviews());
    }
}
