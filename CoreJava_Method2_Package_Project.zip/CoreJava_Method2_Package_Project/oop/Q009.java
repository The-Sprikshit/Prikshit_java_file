package oop;

import java.time.LocalDate;
import java.time.Period;
class Q009Helper1 {
    String name; double salary; LocalDate hireDate;
    Q009Helper1(String name, double salary, LocalDate hireDate) { this.name=name; this.salary=salary; this.hireDate=hireDate; }
    int yearsOfService() { return Period.between(hireDate, LocalDate.now()).getYears(); }
}
public class Q009 {
    public static void main(String[] args) {
        Q009Helper1 e = new Q009Helper1("Neha", 45000, LocalDate.of(2020, 6, 1));
        System.out.println(e.name + " has " + e.yearsOfService() + " years of service.");
    }
}
