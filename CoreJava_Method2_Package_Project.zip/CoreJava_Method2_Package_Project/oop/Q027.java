package oop;

class Q027Helper1 {
    private String accountNumber; private double balance;
    public String getAccountNumber() { return accountNumber; }
    public void setAccountNumber(String accountNumber) { this.accountNumber=accountNumber; }
    public double getBalance() { return balance; }
    public void setBalance(double balance) { if(balance<0) throw new IllegalArgumentException("Negative balance"); this.balance=balance; }
}
public class Q027 {
    public static void main(String[] args) {
        Q027Helper1 a = new Q027Helper1(); a.setAccountNumber("AC101"); a.setBalance(500);
        System.out.println(a.getAccountNumber()+" "+a.getBalance());
    }
}
