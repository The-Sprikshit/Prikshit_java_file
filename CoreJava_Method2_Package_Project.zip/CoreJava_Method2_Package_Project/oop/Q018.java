package oop;

import java.util.*;
class Q018Helper1 {
    Map<String, Double> menu = new LinkedHashMap<>();
    List<Integer> ratings = new ArrayList<>();
    void addItem(String item, double price) { if (price < 0) throw new IllegalArgumentException(); menu.put(item, price); }
    void removeItem(String item) { menu.remove(item); }
    void addRating(int rating) { if (rating < 1 || rating > 5) throw new IllegalArgumentException("Use 1-5"); ratings.add(rating); }
    double averageRating() { return ratings.stream().mapToInt(Integer::intValue).average().orElse(0); }
}
public class Q018 {
    public static void main(String[] args) {
        Q018Helper1 r = new Q018Helper1(); r.addItem("Dosa", 80); r.addRating(4); r.addRating(5);
        System.out.println(r.menu + " average=" + r.averageRating());
    }
}
