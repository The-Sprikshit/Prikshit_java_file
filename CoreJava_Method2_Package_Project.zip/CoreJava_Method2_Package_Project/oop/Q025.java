package oop;

public class Q025 {
    public static void main(String[] args) {
        if (args.length == 0) System.out.println("No command-line arguments supplied.");
        for (int i=0; i<args.length; i++) System.out.println("Argument " + i + ": " + args[i]);
    }
}
