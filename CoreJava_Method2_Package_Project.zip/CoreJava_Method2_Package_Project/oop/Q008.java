package oop;

class Q008Helper1 {
    private String color; private int durationSeconds;
    Q008Helper1(String color, int durationSeconds) { this.color=color; this.durationSeconds=durationSeconds; }
    void changeColor(String color) { this.color=color; }
    boolean isRed() { return color.equalsIgnoreCase("red"); }
    boolean isGreen() { return color.equalsIgnoreCase("green"); }
    int getDurationSeconds() { return durationSeconds; }
}
public class Q008 {
    public static void main(String[] args) {
        Q008Helper1 light = new Q008Helper1("red", 30);
        System.out.println(light.isRed());
        light.changeColor("green");
        System.out.println(light.isGreen());
    }
}
