package oop;

class Q006Helper1 {
    String name, jobTitle;
    double salary;
    Q006Helper1(String name, String jobTitle, double salary) { this.name=name; this.jobTitle=jobTitle; this.salary=salary; }
    void raiseSalary(double percent) { if (percent < 0) throw new IllegalArgumentException(); salary += salary * percent / 100; }
}
public class Q006 {
    public static void main(String[] args) {
        Q006Helper1 e = new Q006Helper1("Ravi", "Developer", 30000);
        e.raiseSalary(10);
        System.out.printf("%s, %s, salary %.2f%n", e.name, e.jobTitle, e.salary);
    }
}
