package oop;

class Q029Helper1 {
    private int employee_id; private String employee_name; private double employee_salary;
    public int getEmployeeId() { return employee_id; } public void setEmployeeId(int id) { employee_id=id; }
    public String getEmployeeName() { return employee_name; } public void setEmployeeName(String name) { employee_name=name; }
    public String getEmployeeSalary() { return String.format("$%,.2f", employee_salary); }
    public void setEmployeeSalary(double salary) { if(salary<0) throw new IllegalArgumentException(); employee_salary=salary; }
}
public class Q029 {
    public static void main(String[] args) {
        Q029Helper1 e = new Q029Helper1(); e.setEmployeeId(7); e.setEmployeeName("Neha"); e.setEmployeeSalary(42500);
        System.out.println(e.getEmployeeId()+" "+e.getEmployeeName()+" "+e.getEmployeeSalary());
    }
}
