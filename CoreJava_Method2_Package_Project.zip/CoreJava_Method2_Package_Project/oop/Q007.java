package oop;

import java.util.*;
class Q007Helper1 {
    String owner; double balance;
    Q007Helper1(String owner, double balance) { this.owner=owner; this.balance=balance; }
    void deposit(double amount) { if (amount <= 0) throw new IllegalArgumentException(); balance += amount; }
    void withdraw(double amount) { if (amount <= 0 || amount > balance) throw new IllegalArgumentException("Invalid withdrawal"); balance -= amount; }
}
class Q007Helper2 {
    Map<String, Q007Helper1> accounts = new HashMap<>();
    void add(Q007Helper1 a) { accounts.put(a.owner, a); }
    void remove(String owner) { accounts.remove(owner); }
    Q007Helper1 find(String owner) { return accounts.get(owner); }
}
public class Q007 {
    public static void main(String[] args) {
        Q007Helper2 bank = new Q007Helper2(); Q007Helper1 a = new Q007Helper1("Aman", 1000);
        bank.add(a); a.deposit(250); a.withdraw(100);
        System.out.println(bank.find("Aman").balance);
    }
}
