package oop;

import java.util.ArrayList;
import java.util.List;
class Q005Helper1 {
    String title, author, isbn;
    Q005Helper1(String title, String author, String isbn) { this.title=title; this.author=author; this.isbn=isbn; }
    public String toString() { return title + " by " + author + " (ISBN " + isbn + ")"; }
}
public class Q005 {
    public static void main(String[] args) {
        List<Q005Helper1> books = new ArrayList<>();
        Q005Helper1 b = new Q005Helper1("Java Basics", "A. Kumar", "ISBN-001");
        books.add(b);
        System.out.println(books);
        books.remove(b);
        System.out.println("Books remaining: " + books.size());
    }
}
