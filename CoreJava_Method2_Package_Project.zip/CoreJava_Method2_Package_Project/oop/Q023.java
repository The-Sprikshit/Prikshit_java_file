package oop;

import java.util.*;
class Q023Helper1 {
    private static int nextRoll = 1;
    int rollNo; String name, className;
    Q023Helper1(String name, String className) { this.rollNo=nextRoll++; this.name=name; this.className=className; }
}
public class Q023 {
    public static void main(String[] args) {
        try (Scanner sc = new Scanner(System.in)) {
            List<Q023Helper1> students = new ArrayList<>();
            for (int i=0; i<10; i++) {
                System.out.print("Name and class: ");
                students.add(new Q023Helper1(sc.nextLine(), sc.nextLine()));
            }
            for (Q023Helper1 s : students) System.out.println(s.rollNo + " " + s.name + " " + s.className);
        }
    }
}
