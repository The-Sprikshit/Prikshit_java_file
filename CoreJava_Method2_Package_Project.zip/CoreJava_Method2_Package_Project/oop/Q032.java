package oop;

import java.util.*;
class Q032Helper1 {
    private int student_id; private String student_name; private final List<Integer> grades = new ArrayList<>();
    public int getStudent_id() { return student_id; } public void setStudent_id(int id) { student_id=id; }
    public String getStudent_name() { return student_name; } public void setStudent_name(String name) { student_name=name; }
    public void addGrade(int grade) { if(grade<0 || grade>100) throw new IllegalArgumentException("Grade must be 0-100"); grades.add(grade); }
    public List<Integer> getGrades() { return Collections.unmodifiableList(grades); }
}
public class Q032 {
    public static void main(String[] args) {
        Q032Helper1 s = new Q032Helper1(); s.setStudent_id(1); s.setStudent_name("Aman"); s.addGrade(85);
        System.out.println(s.getStudent_name()+" "+s.getGrades());
    }
}
