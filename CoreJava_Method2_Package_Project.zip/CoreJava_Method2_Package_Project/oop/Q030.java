package oop;

class Q030Helper1 {
    private double radius;
    public double getRadius() { return radius; }
    public void setRadius(double radius) { if(radius<0) throw new IllegalArgumentException(); this.radius=radius; }
    public double calculateArea() { return Math.PI*radius*radius; }
    public double calculatePerimeter() { return 2*Math.PI*radius; }
}
public class Q030 {
    public static void main(String[] args) {
        Q030Helper1 c = new Q030Helper1(); c.setRadius(4);
        System.out.println(c.calculateArea()); System.out.println(c.calculatePerimeter());
    }
}
