package oop;

class Q004Helper1 {
    double radius;
    Q004Helper1(double radius) { this.radius = radius; }
    double area() { return Math.PI * radius * radius; }
    double circumference() { return 2 * Math.PI * radius; }
}
public class Q004 {
    public static void main(String[] args) {
        Q004Helper1 c = new Q004Helper1(4);
        System.out.println(c.area());
        c.radius = 6;
        System.out.println(c.circumference());
    }
}
