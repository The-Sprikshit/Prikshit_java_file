package oop;

class Q001Helper1 {
    String name;
    int age;
    Q001Helper1(String name, int age) { this.name = name; this.age = age; }
}
public class Q001 {
    public static void main(String[] args) {
        Q001Helper1 p1 = new Q001Helper1("Aman", 20);
        Q001Helper1 p2 = new Q001Helper1("Priya", 21);
        System.out.println(p1.name + ", " + p1.age);
        System.out.println(p2.name + ", " + p2.age);
    }
}
