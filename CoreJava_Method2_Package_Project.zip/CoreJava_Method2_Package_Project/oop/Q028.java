package oop;

class Q028Helper1 {
    private double length, width;
    public double getLength() { return length; } public void setLength(double length) { if(length<0) throw new IllegalArgumentException(); this.length=length; }
    public double getWidth() { return width; } public void setWidth(double width) { if(width<0) throw new IllegalArgumentException(); this.width=width; }
    double area() { return length*width; }
}
public class Q028 {
    public static void main(String[] args) {
        Q028Helper1 r = new Q028Helper1(); r.setLength(5); r.setWidth(3);
        System.out.println(r.area());
    }
}
