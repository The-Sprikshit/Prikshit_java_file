package oop;

import java.util.*;
class Q015Helper1 {
    private final List<String> songs = new ArrayList<>();
    void addSong(String song) { songs.add(song); }
    void removeSong(String song) { songs.remove(song); }
    String playRandomSong() {
        if (songs.isEmpty()) return "No songs in library";
        return songs.get(new Random().nextInt(songs.size()));
    }
}
public class Q015 {
    public static void main(String[] args) {
        Q015Helper1 music = new Q015Helper1();
        music.addSong("Song A"); music.addSong("Song B");
        System.out.println("Playing: " + music.playRandomSong());
    }
}
