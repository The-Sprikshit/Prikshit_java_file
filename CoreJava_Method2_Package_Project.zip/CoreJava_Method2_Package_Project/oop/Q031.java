package oop;

class Q031Helper1 {
    private String company_name, model_name; private int year; private double mileage;
    Q031Helper1(String company, String model, int year, double mileage) { this.company_name=company; this.model_name=model; this.year=year; this.mileage=mileage; }
    public String getCompany_name() { return company_name; } public void setCompany_name(String v) { company_name=v; }
    public String getModel_name() { return model_name; } public void setModel_name(String v) { model_name=v; }
    public int getYear() { return year; } public void setYear(int year) { this.year=year; }
    public double getMileage() { return mileage; }
}
public class Q031 {
    public static void main(String[] args) {
        Q031Helper1 car = new Q031Helper1("Tata","Nexon",2024,18.5); car.setModel_name("Nexon EV");
        System.out.println(car.getCompany_name()+" "+car.getModel_name()+" "+car.getYear()+" "+car.getMileage());
    }
}
