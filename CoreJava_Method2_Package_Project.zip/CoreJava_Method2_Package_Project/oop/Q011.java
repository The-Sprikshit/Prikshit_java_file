package oop;

import java.util.*;
class Q011Helper1 {
    private final List<String> books = new ArrayList<>();
    void addBook(String title) { books.add(title); }
    boolean removeBook(String title) { return books.remove(title); }
    List<String> getBooks() { return Collections.unmodifiableList(books); }
}
public class Q011 {
    public static void main(String[] args) {
        Q011Helper1 library = new Q011Helper1();
        library.addBook("Core Java"); library.addBook("Data Structures");
        library.removeBook("Core Java");
        System.out.println(library.getBooks());
    }
}
