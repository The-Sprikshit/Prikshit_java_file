package oop;

class Q003Helper1 {
    double width, height;
    Q003Helper1(double width, double height) { this.width = width; this.height = height; }
    double area() { return width * height; }
    double perimeter() { return 2 * (width + height); }
}
public class Q003 {
    public static void main(String[] args) {
        Q003Helper1 r = new Q003Helper1(5, 3);
        System.out.println("Area: " + r.area());
        System.out.println("Perimeter: " + r.perimeter());
    }
}
