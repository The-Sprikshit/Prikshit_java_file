package oop;

class Q022Helper1 {
    int rollNo; String name;
    Q022Helper1(int rollNo, String name) { this.rollNo=rollNo; this.name=name; }
    Q022Helper1(Q022Helper1 other) { this(other.rollNo, other.name); }
}
public class Q022 {
    public static void main(String[] args) {
        Q022Helper1 first = new Q022Helper1(101, "Riya");
        Q022Helper1 copy = new Q022Helper1(first);
        System.out.println(copy.rollNo + " " + copy.name);
    }
}
