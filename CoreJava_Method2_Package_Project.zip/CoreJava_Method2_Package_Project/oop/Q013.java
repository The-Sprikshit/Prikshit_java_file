package oop;

import java.util.*;
class Q013Helper1 {
    private final Map<String, Integer> stock = new HashMap<>();
    void add(String product, int quantity) { stock.merge(product, quantity, Integer::sum); }
    void remove(String product) { stock.remove(product); }
    boolean isLow(String product, int threshold) { return stock.getOrDefault(product, 0) < threshold; }
}
public class Q013 {
    public static void main(String[] args) {
        Q013Helper1 inv = new Q013Helper1(); inv.add("Mouse", 3);
        System.out.println("Low stock? " + inv.isLow("Mouse", 5));
    }
}
