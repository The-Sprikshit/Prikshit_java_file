package oop;

import java.util.*;
class Q014Helper1 {
    Set<String> students = new HashSet<>(), teachers = new HashSet<>();
    List<String> classes = new ArrayList<>();
    void addStudent(String name) { students.add(name); }
    void removeStudent(String name) { students.remove(name); }
    void addTeacher(String name) { teachers.add(name); }
    void removeTeacher(String name) { teachers.remove(name); }
    void createClass(String name) { classes.add(name); }
}
public class Q014 {
    public static void main(String[] args) {
        Q014Helper1 school = new Q014Helper1(); school.addStudent("Aman"); school.addTeacher("Ms. Kaur");
        school.createClass("BCA-5"); System.out.println(school.classes);
    }
}
