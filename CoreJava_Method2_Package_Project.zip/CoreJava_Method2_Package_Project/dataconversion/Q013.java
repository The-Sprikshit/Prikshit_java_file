package dataconversion;

public class Q013 {
    public static void main(String[] args) {
        String text = "Hello Java";
        Object object = text;
        System.out.println(object);
    }
}
