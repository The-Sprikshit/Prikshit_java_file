package dataconversion;

public class Q002 {
    public static void main(String[] args) {
        int value = 123;
        String text = String.valueOf(value);
        System.out.println(text);
    }
}
