package dataconversion;

public class Q019 {
    public static void main(String[] args) {
        char letter = 'A';
        int code = letter;
        System.out.println(code); // 65
    }
}
