package dataconversion;

public class Q005 {
    public static void main(String[] args) {
        String text = "12.5";
        float value = Float.parseFloat(text);
        System.out.println(value);
    }
}
