package dataconversion;

import java.sql.Timestamp;
import java.util.Date;
public class Q023 {
    public static void main(String[] args) {

        Date date = new Date();
        Timestamp timestamp = new Timestamp(date.getTime());
        System.out.println(timestamp);
    }
}
