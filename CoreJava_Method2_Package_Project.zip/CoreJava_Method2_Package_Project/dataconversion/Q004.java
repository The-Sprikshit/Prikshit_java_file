package dataconversion;

public class Q004 {
    public static void main(String[] args) {
        long value = 9876543210L;
        String text = Long.toString(value);
        System.out.println(text);
    }
}
