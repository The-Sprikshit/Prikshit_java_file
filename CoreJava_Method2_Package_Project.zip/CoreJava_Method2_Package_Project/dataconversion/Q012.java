package dataconversion;

public class Q012 {
    public static void main(String[] args) {
        char value = 'J';
        String text = String.valueOf(value);
        System.out.println(text);
    }
}
