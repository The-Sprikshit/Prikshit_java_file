package dataconversion;

public class Q020 {
    public static void main(String[] args) {
        int code = 65;
        char letter = (char) code;
        System.out.println(letter); // A
    }
}
