package dataconversion;

public class Q016 {
    public static void main(String[] args) {
        long large = 12345L;
        int value = Math.toIntExact(large);
        System.out.println(value);
    }
}
