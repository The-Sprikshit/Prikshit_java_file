package dataconversion;

public class Q027 {
    public static void main(String[] args) {
        String hex = "2D";
        int decimal = Integer.parseInt(hex, 16);
        System.out.println(decimal);
    }
}
