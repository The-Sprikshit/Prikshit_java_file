package dataconversion;

import java.sql.Timestamp;
import java.util.Date;
public class Q024 {
    public static void main(String[] args) {

        Timestamp timestamp = new Timestamp(System.currentTimeMillis());
        Date date = new Date(timestamp.getTime());
        System.out.println(date);
    }
}
