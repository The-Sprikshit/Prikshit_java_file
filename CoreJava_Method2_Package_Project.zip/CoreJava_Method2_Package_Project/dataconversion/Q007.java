package dataconversion;

public class Q007 {
    public static void main(String[] args) {
        String text = "123.456";
        double value = Double.parseDouble(text);
        System.out.println(value);
    }
}
