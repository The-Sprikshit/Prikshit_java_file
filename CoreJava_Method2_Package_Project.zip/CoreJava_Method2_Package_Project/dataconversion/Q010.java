package dataconversion;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
public class Q010 {
    public static void main(String[] args) {

        LocalDate date = LocalDate.of(2026, 10, 19);
        String text = date.format(DateTimeFormatter.ofPattern("dd-MM-yyyy"));
        System.out.println(text);
    }
}
