package dataconversion;

public class Q014 {
    public static void main(String[] args) {
        Object object = 123;
        String text = String.valueOf(object);
        System.out.println(text);
    }
}
