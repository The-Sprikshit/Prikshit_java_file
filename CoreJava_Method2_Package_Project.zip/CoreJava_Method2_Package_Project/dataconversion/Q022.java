package dataconversion;

public class Q022 {
    public static void main(String[] args) {
        boolean value = true;
        String text = Boolean.toString(value);
        System.out.println(text);
    }
}
