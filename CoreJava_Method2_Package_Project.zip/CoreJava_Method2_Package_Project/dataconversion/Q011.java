package dataconversion;

public class Q011 {
    public static void main(String[] args) {
        String text = "Java";
        char value = text.charAt(0);
        System.out.println(value);
    }
}
