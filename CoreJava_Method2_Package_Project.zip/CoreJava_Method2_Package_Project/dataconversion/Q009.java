package dataconversion;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
public class Q009 {
    public static void main(String[] args) {

        String text = "19-10-2026";
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
        LocalDate date = LocalDate.parse(text, formatter);
        System.out.println(date);
    }
}
