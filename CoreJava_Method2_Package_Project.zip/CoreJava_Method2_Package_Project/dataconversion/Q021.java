package dataconversion;

public class Q021 {
    public static void main(String[] args) {
        String text = "true";
        boolean value = Boolean.parseBoolean(text);
        System.out.println(value);
    }
}
