package dataconversion;

public class Q018 {
    public static void main(String[] args) {
        double value = 25.9;
        int result = (int) value;
        System.out.println(result); // 25
    }
}
