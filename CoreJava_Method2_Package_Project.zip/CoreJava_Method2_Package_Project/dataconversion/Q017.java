package dataconversion;

public class Q017 {
    public static void main(String[] args) {
        int value = 25;
        double result = value;
        System.out.println(result);
    }
}
