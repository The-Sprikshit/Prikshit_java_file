package dataconversion;

public class Q003 {
    public static void main(String[] args) {
        String text = "9876543210";
        long value = Long.parseLong(text);
        System.out.println(value);
    }
}
