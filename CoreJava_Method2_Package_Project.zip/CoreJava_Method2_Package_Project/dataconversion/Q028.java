package dataconversion;

public class Q028 {
    public static void main(String[] args) {
        int decimal = 45;
        String hex = Integer.toHexString(decimal).toUpperCase();
        System.out.println(hex);
    }
}
