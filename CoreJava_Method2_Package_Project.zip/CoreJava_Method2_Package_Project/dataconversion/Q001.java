package dataconversion;

public class Q001 {
    public static void main(String[] args) {
        String text = "123";
        int value = Integer.parseInt(text);
        System.out.println(value);
    }
}
