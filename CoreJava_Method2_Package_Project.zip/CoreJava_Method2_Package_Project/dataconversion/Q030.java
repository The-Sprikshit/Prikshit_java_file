package dataconversion;

public class Q030 {
    public static void main(String[] args) {
        int decimal = 45;
        String octal = Integer.toOctalString(decimal);
        System.out.println(octal);
    }
}
