package dataconversion;

public class Q008 {
    public static void main(String[] args) {
        double value = 123.456;
        String text = Double.toString(value);
        System.out.println(text);
    }
}
