package dataconversion;

public class Q026 {
    public static void main(String[] args) {
        int decimal = 45;
        String binary = Integer.toBinaryString(decimal);
        System.out.println(binary);
    }
}
