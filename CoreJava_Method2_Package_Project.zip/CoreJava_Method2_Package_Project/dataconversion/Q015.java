package dataconversion;

public class Q015 {
    public static void main(String[] args) {
        int small = 1000;
        long large = small;
        System.out.println(large);
    }
}
