package dataconversion;

public class Q006 {
    public static void main(String[] args) {
        float value = 12.5f;
        String text = Float.toString(value);
        System.out.println(text);
    }
}
