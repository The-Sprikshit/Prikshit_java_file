package dataconversion;

public class Q029 {
    public static void main(String[] args) {
        String octal = "55";
        int decimal = Integer.parseInt(octal, 8);
        System.out.println(decimal);
    }
}
