package multithreading;

public class Q012 {
    static class Q012Helper1 {
        private boolean ready = false;
        synchronized void awaitMessage() throws InterruptedException {
            while (!ready) wait();
            System.out.println("Message received");
        }
        synchronized void sendMessage() {
            ready = true;
            notifyAll();
        }
    }
    public static void main(String[] args) throws InterruptedException {
        Q012Helper1 message = new Q012Helper1();
        Thread receiver = new Thread(() -> {
            try { message.awaitMessage(); }
            catch (InterruptedException e) { Thread.currentThread().interrupt(); }
        });
        receiver.start();
        Thread.sleep(200); // demonstration pause
        message.sendMessage();
        receiver.join();
    }
}
