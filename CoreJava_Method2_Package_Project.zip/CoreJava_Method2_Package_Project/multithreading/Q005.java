package multithreading;

public class Q005 {
    static boolean isPrime(int n) {
        if (n < 2) return false;
        for (int i = 2; i * i <= n; i++) if (n % i == 0) return false;
        return true;
    }
    public static void main(String[] args) throws InterruptedException {
        int limit = 100;
        int mid = limit / 2;
        long[] partial = new long[2];
        Thread first = new Thread(() -> { for (int n = 2; n <= mid; n++) if (isPrime(n)) partial[0] += n; });
        Thread second = new Thread(() -> { for (int n = mid + 1; n <= limit; n++) if (isPrime(n)) partial[1] += n; });
        first.start(); second.start(); first.join(); second.join();
        System.out.println("Sum of primes up to " + limit + " = " + (partial[0] + partial[1]));
    }
}
