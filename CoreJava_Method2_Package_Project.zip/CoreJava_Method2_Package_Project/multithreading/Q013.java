package multithreading;

public class Q013 {
    public static void main(String[] args) throws InterruptedException {
        Thread worker = new Thread(() -> {
            for (int i = 1; i <= 3; i++) {
                System.out.println("Worker: " + i);
                Thread.yield(); // hint to the scheduler
            }
        });
        worker.start();
        worker.join(); // wait until worker finishes
        System.out.println("Main continues after worker finishes");
    }
}
