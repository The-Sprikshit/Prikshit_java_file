package multithreading;

public class Q001 {
    public static void main(String[] args) {
        Thread worker = new Thread(() -> System.out.println("Hello, World!"));
        worker.start();
    }
}
