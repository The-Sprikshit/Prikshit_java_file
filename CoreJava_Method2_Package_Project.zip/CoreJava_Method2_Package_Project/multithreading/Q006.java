package multithreading;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class Q006 {
    public static void main(String[] args) {
        List<String> urls = List.of("https://example.com", "https://www.iana.org");
        ExecutorService pool = Executors.newFixedThreadPool(2);
        HttpClient client = HttpClient.newHttpClient();
        for (String url : urls) pool.submit(() -> {
            try {
                HttpRequest request = HttpRequest.newBuilder(URI.create(url)).GET().build();
                HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
                System.out.println(url + " -> HTTP " + response.statusCode() + ", chars=" + response.body().length());
            } catch (Exception e) { System.out.println(url + " failed: " + e.getMessage()); }
        });
        pool.shutdown();
    }
}
