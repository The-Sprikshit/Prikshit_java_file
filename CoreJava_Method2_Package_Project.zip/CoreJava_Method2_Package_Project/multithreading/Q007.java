package multithreading;

public class Q007 {
    static class Q007Helper1 {
        private int balance;
        Q007Helper1(int initialBalance) { balance = initialBalance; }
        synchronized void deposit(int amount) { balance += amount; }
        synchronized boolean withdraw(int amount) {
            if (amount > balance) return false;
            balance -= amount; return true;
        }
        synchronized int getBalance() { return balance; }
    }
    public static void main(String[] args) throws InterruptedException {
        Q007Helper1 account = new Q007Helper1(1000);
        Thread depositor = new Thread(() -> { for (int i = 0; i < 100; i++) account.deposit(10); });
        Thread withdrawer = new Thread(() -> { for (int i = 0; i < 50; i++) account.withdraw(5); });
        depositor.start(); withdrawer.start(); depositor.join(); withdrawer.join();
        System.out.println("Final balance: " + account.getBalance());
    }
}
