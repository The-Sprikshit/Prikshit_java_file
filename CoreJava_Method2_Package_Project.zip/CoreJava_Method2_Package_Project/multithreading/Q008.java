package multithreading;

public class Q008 {
    public static void main(String[] args) throws InterruptedException {
        Runnable task = () -> System.out.println("Running on " + Thread.currentThread().getName());
        Thread t1 = new Thread(task, "Worker-1");
        Thread t2 = new Thread(task, "Worker-2");
        t1.start(); t2.start();
        t1.join(); t2.join();
    }
}
