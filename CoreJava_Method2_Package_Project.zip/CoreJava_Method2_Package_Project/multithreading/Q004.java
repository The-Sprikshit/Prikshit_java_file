package multithreading;

import java.util.Arrays;

public class Q004 {
    public static void main(String[] args) throws InterruptedException {
        int[][] a = {{1, 2}, {3, 4}};
        int[][] b = {{5, 6}, {7, 8}};
        int[][] result = new int[2][2];
        Thread[] workers = new Thread[2];
        for (int row = 0; row < 2; row++) {
            final int r = row;
            workers[row] = new Thread(() -> {
                for (int col = 0; col < 2; col++)
                    for (int k = 0; k < 2; k++) result[r][col] += a[r][k] * b[k][col];
            });
            workers[row].start();
        }
        for (Thread worker : workers) worker.join();
        for (int[] row : result) System.out.println(Arrays.toString(row));
    }
}
