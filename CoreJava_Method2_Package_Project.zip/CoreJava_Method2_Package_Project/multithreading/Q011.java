package multithreading;

public class Q011 {
    static class Q011Helper1 {
        private int count = 0;
        synchronized void increment() { count++; }
        synchronized int getCount() { return count; }
    }
    public static void main(String[] args) throws InterruptedException {
        Q011Helper1 counter = new Q011Helper1();
        Runnable task = () -> { for (int i = 0; i < 10000; i++) counter.increment(); };
        Thread t1 = new Thread(task); Thread t2 = new Thread(task);
        t1.start(); t2.start(); t1.join(); t2.join();
        System.out.println("Count = " + counter.getCount()); // 20000
    }
}
