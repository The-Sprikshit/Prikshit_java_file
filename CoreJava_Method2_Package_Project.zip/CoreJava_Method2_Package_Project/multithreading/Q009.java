package multithreading;

public class Q009 {
    static class Q009Helper1 extends Thread {
        Q009Helper1(String name) { super(name); }
        public void run() { System.out.println("Hello from " + getName()); }
    }
    public static void main(String[] args) throws InterruptedException {
        Thread t1 = new Q009Helper1("Worker-1");
        Thread t2 = new Q009Helper1("Worker-2");
        t1.start(); t2.start();
        t1.join(); t2.join();
    }
}
