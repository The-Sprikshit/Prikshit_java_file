package multithreading;

import java.util.Arrays;

public class Q003 {
    public static void main(String[] args) throws InterruptedException {
        int[] values = {9, 3, 7, 1, 6, 2};
        int middle = values.length / 2;
        int[] left = Arrays.copyOfRange(values, 0, middle);
        int[] right = Arrays.copyOfRange(values, middle, values.length);
        Thread t1 = new Thread(() -> Arrays.sort(left));
        Thread t2 = new Thread(() -> Arrays.sort(right));
        t1.start(); t2.start(); t1.join(); t2.join();
        int[] result = new int[values.length];
        int i = 0, a = 0, b = 0;
        while (a < left.length && b < right.length)
            result[i++] = left[a] <= right[b] ? left[a++] : right[b++];
        while (a < left.length) result[i++] = left[a++];
        while (b < right.length) result[i++] = right[b++];
        System.out.println(Arrays.toString(result));
    }
}
