package multithreading;

public class Q010 {
    public static void main(String[] args) throws InterruptedException {
        Runnable task = () -> System.out.println(Thread.currentThread().getName() + " priority=" + Thread.currentThread().getPriority());
        Thread t1 = new Thread(task, "LowPriority");
        Thread t2 = new Thread(task, "HighPriority");
        t1.setPriority(Thread.MIN_PRIORITY);
        t2.setPriority(Thread.MAX_PRIORITY);
        t1.start(); t2.start();
        t1.join(); t2.join();
    }
}
