package exceptionhandling;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Q009 {
    public static void main(String[] args) {
        String driverClass = "com.example.jdbc.Driver"; // Replace with your driver's class
        String url = "jdbc:your_database_url";
        String username = "username";
        String password = "password";
        try {
            Class.forName(driverClass);
            try (Connection connection = DriverManager.getConnection(url, username, password)) {
                System.out.println("Driver loaded and connection established.");
            }
        } catch (ClassNotFoundException | SQLException e) {
            throw new IllegalStateException("Driver loading or database connection failed", e);
        }
    }
}
