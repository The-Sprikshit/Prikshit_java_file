package exceptionhandling;

import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;

public class Q006 {
    static void checkDuplicates(int[] numbers) {
        Set<Integer> seen = new HashSet<>();
        for (int number : numbers) {
            if (!seen.add(number)) throw new IllegalArgumentException("Duplicate number: " + number);
        }
        System.out.println("No duplicates found.");
    }
    public static void main(String[] args) {
        try (Scanner sc = new Scanner(System.in)) {
            System.out.print("How many integers? ");
            int n = sc.nextInt();
            int[] numbers = new int[n];
            for (int i = 0; i < n; i++) numbers[i] = sc.nextInt();
            try { checkDuplicates(numbers); }
            catch (IllegalArgumentException e) { System.out.println(e.getMessage()); }
        }
    }
}
