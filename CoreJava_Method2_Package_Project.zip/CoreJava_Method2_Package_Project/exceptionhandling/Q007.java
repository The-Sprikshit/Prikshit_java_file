package exceptionhandling;

public class Q007 {
    static void checkVowel(String text) {
        if (text == null || !text.matches("(?is).* [aeiou].*".replace(" ", ""))) {
            throw new IllegalArgumentException("String does not contain a vowel");
        }
        System.out.println("String contains a vowel.");
    }
    public static void main(String[] args) {
        try { checkVowel("rhythm"); }
        catch (IllegalArgumentException e) { System.out.println(e.getMessage()); }
    }
}
