package exceptionhandling;

public class Q012 {
    public static void main(String[] args) {
        try {
            int[] values = {10, 20};
            int divisor = Integer.parseInt(args.length == 0 ? "0" : args[0]);
            System.out.println(values[3] / divisor);
        } catch (ArithmeticException e) {
            System.out.println("Cannot divide by zero.");
        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("Array index is out of range.");
        } catch (NumberFormatException e) {
            System.out.println("Please provide a valid integer argument.");
        }
    }
}
