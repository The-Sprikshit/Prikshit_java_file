package exceptionhandling;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class Q010 {
    static void insertExample(Connection connection, int id, String name) throws SQLException {
        String sql = "INSERT INTO students (id, name) VALUES (?, ?)";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, id);
            statement.setString(2, name);
            int changed = statement.executeUpdate();
            if (changed != 1) throw new SQLException("Insert did not affect exactly one row");
        }
    }
    public static void main(String[] args) {
        String url = "jdbc:your_database_url";
        try (Connection connection = DriverManager.getConnection(url, "username", "password")) {
            insertExample(connection, 1, "Aman");
            System.out.println("Insert successful");
        } catch (SQLException e) {
            System.out.println("SQL operation failed: " + e.getMessage());
        }
    }
}
