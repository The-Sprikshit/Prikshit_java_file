package exceptionhandling;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Q008 {
    public static void main(String[] args) {
        String url = "jdbc:your_database_url"; // Replace with your JDBC URL
        try (Connection connection = DriverManager.getConnection(url, "username", "password")) {
            System.out.println("Database connected successfully.");
        } catch (SQLException e) {
            System.out.println("Database connection failed: " + e.getMessage());
        }
    }
}
