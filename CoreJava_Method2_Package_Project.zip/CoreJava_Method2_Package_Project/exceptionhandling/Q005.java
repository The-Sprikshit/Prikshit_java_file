package exceptionhandling;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

public class Q005 {
    static String readNonEmptyFile(String fileName) throws IOException {
        String text = Files.readString(Path.of(fileName));
        if (text.isBlank()) throw new IllegalArgumentException("File is empty");
        return text;
    }
    public static void main(String[] args) {
        try { System.out.println(readNonEmptyFile("input.txt")); }
        catch (IOException | IllegalArgumentException e) { System.out.println(e.getMessage()); }
    }
}
