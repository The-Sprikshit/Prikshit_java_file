package exceptionhandling;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

public class Q003 {
    static String readFile(String fileName) throws IOException {
        Path path = Path.of(fileName);
        if (!Files.exists(path)) throw new IOException("File not found: " + fileName);
        return Files.readString(path);
    }
    public static void main(String[] args) {
        try { System.out.println(readFile("input.txt")); }
        catch (IOException e) { System.out.println(e.getMessage()); }
    }
}
