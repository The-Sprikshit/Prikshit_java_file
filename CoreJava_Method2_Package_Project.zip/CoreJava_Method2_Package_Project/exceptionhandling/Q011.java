package exceptionhandling;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

public class Q011 {
    static String loadText(String fileName) throws IOException {
        return Files.readString(Path.of(fileName));
    }
    public static void main(String[] args) {
        try { System.out.println(loadText("input.txt")); }
        catch (IOException e) { System.out.println("Could not read file: " + e.getMessage()); }
    }
}
