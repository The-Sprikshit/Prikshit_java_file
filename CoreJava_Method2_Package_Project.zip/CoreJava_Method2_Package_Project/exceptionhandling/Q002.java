package exceptionhandling;

public class Q002 {
    static void checkEven(int number) {
        if (number % 2 != 0) throw new IllegalArgumentException("Number must be even");
        System.out.println(number + " is even");
    }
    public static void main(String[] args) {
        try { checkEven(7); }
        catch (IllegalArgumentException e) { System.out.println(e.getMessage()); }
    }
}
