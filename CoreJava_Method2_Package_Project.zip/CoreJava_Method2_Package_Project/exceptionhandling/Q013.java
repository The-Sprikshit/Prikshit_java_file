package exceptionhandling;

public class Q013 {
    public static void main(String[] args) {
        try {
            System.out.println("Outer try block");
            try {
                int[] values = {1, 2, 3};
                System.out.println(values[5]);
            } catch (ArrayIndexOutOfBoundsException e) {
                System.out.println("Inner catch: invalid array index");
            }
            int result = 10 / 0;
            System.out.println(result);
        } catch (ArithmeticException e) {
            System.out.println("Outer catch: division by zero");
        }
    }
}
