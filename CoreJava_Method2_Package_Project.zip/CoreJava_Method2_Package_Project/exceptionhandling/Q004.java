package exceptionhandling;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

public class Q004 {
    static void checkNumbers(String fileName) throws IOException {
        for (String token : Files.readString(Path.of(fileName)).trim().split("\\s+")) {
            if (token.isEmpty()) continue;
            int number = Integer.parseInt(token);
            if (number > 0) throw new IllegalArgumentException("Positive number found: " + number);
        }
        System.out.println("No positive numbers found.");
    }
    public static void main(String[] args) {
        try { checkNumbers("numbers.txt"); }
        catch (IOException | IllegalArgumentException e) { System.out.println(e.getMessage()); }
    }
}
