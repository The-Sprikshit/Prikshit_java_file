package functions;

public class Q007 {
    static boolean isValidPassword(String password) {
        if (password == null || password.length() < 8) return false;
        boolean hasLetter = false, hasDigit = false;
        for (char ch : password.toCharArray()) {
            if (Character.isLetter(ch)) hasLetter = true;
            if (Character.isDigit(ch)) hasDigit = true;
        }
        return hasLetter && hasDigit;
    }

    public static void main(String[] args) {
        System.out.println(isValidPassword("Java1234"));
    }
}
