package functions;

public class Q010 {
    static int countTwos(int number) {
        int count = 0;
        do {
            if (number % 10 == 2) count++;
            number /= 10;
        } while (number > 0);
        return count;
    }

    public static void main(String[] args) {
        System.out.println(countTwos(22012));
    }
}
