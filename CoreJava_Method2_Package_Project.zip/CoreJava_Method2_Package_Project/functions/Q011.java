package functions;

import java.util.Arrays;

public class Q011 {
    static boolean areConsecutive(int a, int b, int c) {
        int[] values = {a, b, c};
        Arrays.sort(values);
        return (long) values[1] == (long) values[0] + 1
            && (long) values[2] == (long) values[1] + 1;
    }

    public static void main(String[] args) {
        System.out.println(areConsecutive(4, 2, 3)); // true
        System.out.println(areConsecutive(4, 2, 8)); // false
    }
}
