package functions;

public class Q002 {
    static double average(double a, double b, double c) {
        return (a + b + c) / 3.0;
    }

    public static void main(String[] args) {
        System.out.println(average(10, 20, 30));
    }
}
