package functions;

public class Q012 {
    static boolean isMidpoint(int a, int b, int c) {
        return (long) a + c == 2L * b
            || (long) a + b == 2L * c
            || (long) b + c == 2L * a;
    }

    public static void main(String[] args) {
        System.out.println(isMidpoint(2, 4, 6)); // true
        System.out.println(isMidpoint(2, 5, 9)); // false
    }
}
