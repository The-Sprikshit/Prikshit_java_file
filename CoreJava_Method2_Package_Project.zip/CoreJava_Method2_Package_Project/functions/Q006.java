package functions;

public class Q006 {
    static void printCharacters(char start, char end) {
        if (start <= end) {
            for (char ch = start; ch <= end; ch++) {
                System.out.print(ch + " ");
            }
        } else {
            for (char ch = start; ch >= end; ch--) {
                System.out.print(ch + " ");
            }
        }
        System.out.println();
    }

    public static void main(String[] args) {
        printCharacters('A', 'P');
    }
}
