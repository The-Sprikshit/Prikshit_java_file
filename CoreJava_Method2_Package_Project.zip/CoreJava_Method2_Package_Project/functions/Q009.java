package functions;

public class Q009 {
    static boolean isPrime(int n) {
        if (n < 2) return false;
        for (int i = 2; i * i <= n; i++) {
            if (n % i == 0) return false;
        }
        return true;
    }

    public static void main(String[] args) {
        for (int n = 2; n + 2 < 100; n++) {
            if (isPrime(n) && isPrime(n + 2)) {
                System.out.println("(" + n + ", " + (n + 2) + ")");
            }
        }
    }
}
