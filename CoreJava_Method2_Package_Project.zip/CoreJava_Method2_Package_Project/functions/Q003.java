package functions;

public class Q003 {
    static String middle(String text) {
        if (text == null || text.isEmpty()) return "";
        int mid = text.length() / 2;
        if (text.length() % 2 == 1) {
            return text.substring(mid, mid + 1);
        }
        return text.substring(mid - 1, mid + 1);
    }

    public static void main(String[] args) {
        System.out.println(middle("Java")); // av
        System.out.println(middle("Hello")); // l
    }
}
