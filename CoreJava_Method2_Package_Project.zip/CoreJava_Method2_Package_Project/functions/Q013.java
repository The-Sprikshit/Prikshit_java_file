package functions;

public class Q013 {
    static boolean allVowels(String text) {
        if (text == null || text.isEmpty()) return false;
        for (char ch : text.toLowerCase().toCharArray()) {
            if ("aeiou".indexOf(ch) == -1) return false;
        }
        return true;
    }

    public static void main(String[] args) {
        System.out.println(allVowels("aeIOu")); // true
        System.out.println(allVowels("audio")); // false
    }
}
