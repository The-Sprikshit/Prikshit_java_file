package functions;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class Q008 {
    static void showDateTime() {
        DateTimeFormatter format =
            DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss");
        System.out.println(LocalDateTime.now().format(format));
    }

    public static void main(String[] args) {
        showDateTime();
    }
}
