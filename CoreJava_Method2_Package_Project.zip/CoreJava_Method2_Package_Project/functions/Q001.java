package functions;

public class Q001 {
    static int smallest(int a, int b, int c) {
        return Math.min(a, Math.min(b, c));
    }

    public static void main(String[] args) {
        System.out.println(smallest(14, 7, 22));
    }
}
