package functions;

public class Q004 {
    static int countWords(String text) {
        if (text == null || text.trim().isEmpty()) return 0;
        return text.trim().split("\\s+").length;
    }

    public static void main(String[] args) {
        System.out.println(countWords("Java is easy to learn"));
    }
}
