package functions;

public class Q005 {
    static double futureValue(double amount, double annualRate, int years) {
        return amount * Math.pow(1 + annualRate / 100.0, years);
    }

    public static void main(String[] args) {
        System.out.printf("%.2f%n", futureValue(1000, 5, 3));
    }
}
