package multidimensionalarrays;

public class Q007 {
    public static void main(String[] args) {
        int[][] a = {{1, 2, 3}, {4, 5, 6}, {7, 8, 9}};
        for (int i = 0; i < a.length; i++) {
            for (int j = 0; j < a[i].length; j++)
                System.out.print((j >= i ? a[i][j] : 0) + " ");
            System.out.println();
        }
    }
}
