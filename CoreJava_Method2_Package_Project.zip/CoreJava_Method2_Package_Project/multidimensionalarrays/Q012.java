package multidimensionalarrays;

public class Q012 {
    public static void main(String[] args) {
        int[][] a = {{2, 4}, {6, 8}, {10, 12}};
        for (int j = 0; j < a[0].length; j++) {
            for (int i = 0; i < a.length; i++) System.out.print(a[i][j] + " ");
            System.out.println();
        }
    }
}
