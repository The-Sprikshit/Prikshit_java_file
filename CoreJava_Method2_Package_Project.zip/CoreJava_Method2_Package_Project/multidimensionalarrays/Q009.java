package multidimensionalarrays;

public class Q009 {
    public static void main(String[] args) {
        int[][] a = {{1, 2, 3}, {4, 5, 6}};
        for (int i = 0; i < a.length; i++) {
            int sum = 0;
            for (int value : a[i]) sum += value;
            System.out.println("Row " + i + " sum: " + sum);
        }
        for (int j = 0; j < a[0].length; j++) {
            int sum = 0;
            for (int i = 0; i < a.length; i++) sum += a[i][j];
            System.out.println("Column " + j + " sum: " + sum);
        }
    }
}
