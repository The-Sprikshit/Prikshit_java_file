package multidimensionalarrays;

public class Q013 {
    public static void main(String[] args) {
        int[][] a = {{0, 0, 3}, {0, 0, 0}, {4, 0, 0}};
        int zeros = 0, total = 0;
        for (int[] row : a)
            for (int value : row) {
                total++;
                if (value == 0) zeros++;
            }
        System.out.println(zeros > total / 2 ? "Sparse matrix" : "Not sparse");
    }
}
