package multidimensionalarrays;

public class Q010 {
    public static void main(String[] args) {
        int[][] a = {{1, 2, 3}, {4, 5, 6}};
        int[][] t = new int[a[0].length][a.length];
        for (int i = 0; i < a.length; i++)
            for (int j = 0; j < a[i].length; j++) t[j][i] = a[i][j];
        for (int[] row : t) {
            for (int x : row) System.out.print(x + " ");
            System.out.println();
        }
    }
}
