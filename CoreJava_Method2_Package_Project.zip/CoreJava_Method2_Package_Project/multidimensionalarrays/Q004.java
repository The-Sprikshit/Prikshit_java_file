package multidimensionalarrays;

public class Q004 {
    public static void main(String[] args) {
        int[][] a = {{8, 7}, {6, 5}};
        int[][] b = {{1, 2}, {3, 4}};
        int[][] result = new int[2][2];
        for (int i = 0; i < 2; i++)
            for (int j = 0; j < 2; j++) result[i][j] = a[i][j] - b[i][j];
        for (int[] row : result) {
            for (int x : row) System.out.print(x + " ");
            System.out.println();
        }
    }
}
