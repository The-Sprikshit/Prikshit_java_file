package multidimensionalarrays;

import java.util.Arrays;
public class Q005 {
    public static void main(String[] args) {
        int[][] a = {{1, 2}, {3, 4}};
        int[][] b = {{1, 2}, {3, 4}};
        boolean equal = a.length == b.length;
        if (equal) {
            for (int i = 0; i < a.length; i++)
                if (!Arrays.equals(a[i], b[i])) equal = false;
        }
        System.out.println(equal);
    }
}
