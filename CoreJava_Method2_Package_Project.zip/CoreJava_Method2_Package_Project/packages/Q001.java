package packages;

import java.util.Date;

public class Q001 {
    public static void main(String[] args) {
        Date today = new Date();
        System.out.println(today);
    }
}
