package packages;

import java.util.Date;

class Q003Helper1 extends Date {
    // Inherits Date's date/time behaviour.
}

public class Q003 {
    public static void main(String[] args) {
        Q003Helper1 today = new Q003Helper1();
        System.out.println(today);
    }
}
