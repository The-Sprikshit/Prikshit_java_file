package packages;

class Q006Helper1 { void show() { System.out.println("One"); } }
class Q006Helper2 { void show() { System.out.println("Two"); } }
class Q006Helper3 { void show() { System.out.println("Three"); } }
class Q006Helper4 { void show() { System.out.println("Four"); } }
public class Q006 {
    public static void main(String[] args) {
        new Q006Helper1().show();
        new Q006Helper2().show();
        new Q006Helper3().show();
        new Q006Helper4().show();
    }
}
