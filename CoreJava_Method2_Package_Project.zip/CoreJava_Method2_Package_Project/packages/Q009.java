package packages;

class Q009Helper1 {
    protected void display() { System.out.println("Protected member in c4.sample"); }
}
class Q009Helper2 extends Q009Helper1 {
    public void test() { display(); }
}
public class Q009 {
    public static void main(String[] args) { new Q009Helper2().test(); }
}
