package packages;

class Q007Helper1 {
    public String name, empid, category;
    public double bpay, hra, da, npay, pf, grosspay, incometax, allowance;
    public Q007Helper1(String name, String empid, String category, double bpay) {
        this.name = name; this.empid = empid; this.category = category; this.bpay = bpay;
    }
    public void calculate() {
        hra = bpay * 0.20; da = bpay * 0.10; allowance = 1000;
        grosspay = bpay + hra + da + allowance; pf = bpay * 0.12;
        incometax = grosspay * 0.05; npay = grosspay - pf - incometax;
    }
    public void printSlip() {
        System.out.println("Employee: " + name + " (" + empid + ")");
        System.out.println("Category: " + category);
        System.out.println("Gross pay: " + grosspay);
        System.out.println("PF: " + pf);
        System.out.println("Income tax: " + incometax);
        System.out.println("Net pay: " + npay);
    }
}
public class Q007 {
    public static void main(String[] args) {
        Q007Helper1 e = new Q007Helper1("Aman", "E101", "Staff", 30000);
        e.calculate(); e.printSlip();
    }
}
