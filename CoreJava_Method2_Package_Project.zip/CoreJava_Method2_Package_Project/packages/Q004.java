package packages;

class Q004Helper1 extends java.util.Date {
    // Uses the fully qualified parent class name.
}

public class Q004 {
    public static void main(String[] args) {
        Q004Helper1 today = new Q004Helper1();
        System.out.println(today);
    }
}
