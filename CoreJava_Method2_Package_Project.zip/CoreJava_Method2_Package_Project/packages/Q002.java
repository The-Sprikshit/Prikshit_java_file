package packages;

public class Q002 {
    public static void main(String[] args) {
        java.util.Date today = new java.util.Date();
        System.out.println(today);
    }
}
