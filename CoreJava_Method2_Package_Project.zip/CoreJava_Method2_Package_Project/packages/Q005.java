package packages;

class Q005Helper1 {
    void show() { System.out.println("First class"); }
}

class Q005Helper2 {
    void show() { System.out.println("Second class"); }
}

public class Q005 {
    public static void main(String[] args) {
        new Q005Helper1().show();
        new Q005Helper2().show();
    }
}
