package packages;

class Q008Helper1 {
    protected void display() { System.out.println("Protected member accessed"); }
}
class Q008Helper2 extends Q008Helper1 {
    public void test() { display(); }
}
public class Q008 {
    public static void main(String[] args) { new Q008Helper2().test(); }
}
