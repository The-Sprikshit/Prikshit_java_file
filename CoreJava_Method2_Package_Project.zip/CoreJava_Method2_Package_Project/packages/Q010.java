package packages;

class Q010Helper1 {
    public void sayHello() { System.out.println("Hello from another package"); }
}
public class Q010 {
    public static void main(String[] args) {
        Q010Helper1 greeter = new Q010Helper1();
        greeter.sayHello();
    }
}
