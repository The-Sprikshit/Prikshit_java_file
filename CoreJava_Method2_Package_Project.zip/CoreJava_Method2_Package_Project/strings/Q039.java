package strings;

public class Q039 {
    public static void main(String[] args) {
        String s = "Java is fun";
        System.out.println(s.replace(' ', '-'));
    }
}
