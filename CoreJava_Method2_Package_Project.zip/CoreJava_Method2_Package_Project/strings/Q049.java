package strings;

public class Q049 {
    public static void main(String[] args) {
        StringBuffer buffer = new StringBuffer("Java");
        System.out.println(buffer.reverse());
    }
}
