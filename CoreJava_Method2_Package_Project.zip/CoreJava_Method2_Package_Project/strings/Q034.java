package strings;

public class Q034 {
    public static void main(String[] args) {
        System.out.println("Hello\nJava");
    }
}
