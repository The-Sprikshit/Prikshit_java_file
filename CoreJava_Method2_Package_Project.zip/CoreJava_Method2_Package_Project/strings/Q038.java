package strings;

public class Q038 {
    public static void main(String[] args) {
        String s = "JaVa ProGram";
        StringBuilder out = new StringBuilder();
        for (char ch : s.toCharArray()) {
            if (Character.isUpperCase(ch)) out.append(Character.toLowerCase(ch));
            else if (Character.isLowerCase(ch)) out.append(Character.toUpperCase(ch));
            else out.append(ch);
        }
        System.out.println(out);
    }
}
