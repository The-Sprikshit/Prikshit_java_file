package strings;

import java.util.Arrays;
public class Q047 {
    static String normalized(String s) {
        char[] a = s.replaceAll("\\s+", "").toLowerCase().toCharArray();
        Arrays.sort(a);
        return new String(a);
    }
    public static void main(String[] args) {
        System.out.println(normalized("abc").equals(normalized("bca")));
    }
}
