package strings;

public class Q016 {
    public static void main(String[] args) {
        String s = "Java is awesome";
        int vowels = 0, consonants = 0;
        for (char ch : s.toLowerCase().toCharArray()) {
            if (ch >= 'a' && ch <= 'z') {
                if ("aeiou".indexOf(ch) >= 0) vowels++;
                else consonants++;
            }
        }
        System.out.println("Vowels: " + vowels + ", consonants: " + consonants);
    }
}
