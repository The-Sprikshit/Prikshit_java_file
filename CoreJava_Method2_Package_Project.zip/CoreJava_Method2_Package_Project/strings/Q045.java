package strings;

public class Q045 {
    public static void main(String[] args) {
        String s = "Java";
        StringBuilder out = new StringBuilder();
        for (int i = s.length() - 1; i >= 0; i--) out.append(s.charAt(i));
        System.out.println(out);
    }
}
