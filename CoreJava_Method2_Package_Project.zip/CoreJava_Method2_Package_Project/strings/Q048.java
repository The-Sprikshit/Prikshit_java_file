package strings;

import java.util.LinkedHashMap;
import java.util.Map;
public class Q048 {
    public static void main(String[] args) {
        String s = "swiss";
        Map<Character, Integer> count = new LinkedHashMap<>();
        for (char ch : s.toCharArray()) count.put(ch, count.getOrDefault(ch, 0) + 1);
        for (var e : count.entrySet()) {
            if (e.getValue() == 1) { System.out.println(e.getKey()); break; }
        }
    }
}
