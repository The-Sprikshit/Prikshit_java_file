package strings;

public class Q036 {
    public static void main(String[] args) {
        String s = "level madam civic noon";
        String smallest = null, largest = "";
        for (String word : s.split("\\s+")) {
            if (word.equals(new StringBuilder(word).reverse().toString())) {
                if (smallest == null || word.length() < smallest.length()) smallest = word;
                if (word.length() > largest.length()) largest = word;
            }
        }
        System.out.println("Smallest: " + smallest + ", largest: " + largest);
    }
}
