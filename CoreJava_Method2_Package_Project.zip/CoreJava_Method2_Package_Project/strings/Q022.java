package strings;

import java.util.*;
public class Q022 {
    public static void main(String[] args) {
        String s = "banana";
        Map<Character, Integer> counts = new LinkedHashMap<>();
        for (char ch : s.toCharArray()) counts.put(ch, counts.getOrDefault(ch, 0) + 1);
        char min = 0, max = 0; int low = Integer.MAX_VALUE, high = 0;
        for (var e : counts.entrySet()) {
            if (e.getValue() < low) { low = e.getValue(); min = e.getKey(); }
            if (e.getValue() > high) { high = e.getValue(); max = e.getKey(); }
        }
        System.out.println("Min: " + min + ", max: " + max);
    }
}
