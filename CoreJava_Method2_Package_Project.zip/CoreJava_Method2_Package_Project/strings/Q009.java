package strings;

import java.util.Arrays;
public class Q009 {
    static String normalize(String s) {
        char[] chars = s.replaceAll("\\s+", "").toLowerCase().toCharArray();
        Arrays.sort(chars);
        return new String(chars);
    }
    public static void main(String[] args) {
        System.out.println(normalize("listen").equals(normalize("silent")));
    }
}
