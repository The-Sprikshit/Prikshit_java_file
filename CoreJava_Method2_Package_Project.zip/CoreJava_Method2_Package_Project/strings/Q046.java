package strings;

import java.util.Arrays;
public class Q046 {
    public static void main(String[] args) {
        String s = "Java makes coding fun";
        String[] words = s.split("\\s+");
        for (int i = words.length - 1; i >= 0; i--)
            System.out.print(words[i] + (i > 0 ? " " : ""));
    }
}
