package strings;

import java.util.Arrays;
public class Q019 {
    static void splitEqual(String s, int n) {
        if (n <= 0 || s.length() % n != 0) {
            System.out.println("Cannot divide equally");
            return;
        }
        int size = s.length() / n;
        for (int i = 0; i < s.length(); i += size)
            System.out.println(s.substring(i, i + size));
    }
    public static void main(String[] args) { splitEqual("ABCDEFGHIJKL", 4); }
}
