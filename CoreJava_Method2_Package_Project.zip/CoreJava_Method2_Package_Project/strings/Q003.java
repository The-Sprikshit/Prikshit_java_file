package strings;

public class Q003 {
    public static void main(String[] args) {
        String original = "Java";
        String changed = original.concat(" Programming");
        System.out.println(original); // Java
        System.out.println(changed);
    }
}
