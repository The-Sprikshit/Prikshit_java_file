package strings;

public class Q006 {
    public static void main(String[] args) {
        StringBuffer sb = new StringBuffer("Java");
        sb.insert(0, "Core ");
        System.out.println(sb);
    }
}
