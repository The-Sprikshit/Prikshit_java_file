package strings;

public class Q020 {
    public static void main(String[] args) {
        String s = "abc";
        int total = 1 << s.length();
        for (int mask = 0; mask < total; mask++) {
            StringBuilder subset = new StringBuilder();
            for (int i = 0; i < s.length(); i++)
                if ((mask & (1 << i)) != 0) subset.append(s.charAt(i));
            System.out.println(subset);
        }
    }
}
