package strings;

public class Q028 {
    public static void main(String[] args) {
        String s = "abcabc";
        String longest = "";
        for (int len = s.length() / 2; len > 0 && longest.isEmpty(); len--) {
            for (int i = 0; i + 2 * len <= s.length(); i++) {
                String part = s.substring(i, i + len);
                if (s.indexOf(part, i + len) >= 0) { longest = part; break; }
            }
        }
        System.out.println(longest);
    }
}
