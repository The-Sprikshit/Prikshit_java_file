package strings;

public class Q018 {
    public static void main(String[] args) {
        String a = "ABCD", b = "CDAB";
        System.out.println(a.length() == b.length() && (a + a).contains(b));
    }
}
