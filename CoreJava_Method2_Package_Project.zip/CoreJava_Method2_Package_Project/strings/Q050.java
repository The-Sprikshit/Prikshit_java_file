package strings;

public class Q050 {
    public static void main(String[] args) {
        StringBuffer sb = new StringBuffer("Java");
        sb.insert(0, "Core ");
        sb.append(" Language");
        sb.delete(0, 5);
        sb.replace(0, 4, "JAVA");
        System.out.println(sb);
    }
}
