package strings;

import java.util.*;
public class Q024 {
    public static void main(String[] args) {
        String s = "programming";
        Set<Character> seen = new HashSet<>(), duplicates = new LinkedHashSet<>();
        for (char ch : s.toCharArray()) if (!seen.add(ch)) duplicates.add(ch);
        System.out.println(duplicates);
    }
}
