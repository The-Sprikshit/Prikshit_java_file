package strings;

import java.util.Arrays;
public class Q041 {
    public static void main(String[] args) {
        String s = "one two three four";
        int n = 3;
        System.out.println(Arrays.toString(s.split("\\s+", n)));
    }
}
