package strings;

public class Q014 {
    public static void main(String[] args) {
        String s = "Hello Java";
        System.out.println("Characters: " + s.length());
        System.out.println("Code points: " +
            s.codePointCount(0, s.length()));
    }
}
