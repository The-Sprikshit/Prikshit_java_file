package strings;

enum Q011Helper1 { MONDAY, TUESDAY, WEDNESDAY }
public class Q011 {
    public static void main(String[] args) {
        Q011Helper1 day = Q011Helper1.MONDAY;
        String text = day.name();
        System.out.println(text);
    }
}
