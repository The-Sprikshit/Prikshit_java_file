package strings;

public class Q043 {
    public static void main(String[] args) {
        String s = "ABCDEFG";
        char[] chars = s.toCharArray();
        for (int i = 0; i + 1 < chars.length; i += 2) {
            char temp = chars[i]; chars[i] = chars[i+1]; chars[i+1] = temp;
        }
        System.out.println(new String(chars));
    }
}
