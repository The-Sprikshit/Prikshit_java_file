package strings;

import java.nio.file.*;
import java.io.IOException;
import java.util.*;
public class Q029 {
    public static void main(String[] args) throws IOException {
        Map<String, Integer> counts = new HashMap<>();
        for (String line : Files.readAllLines(Path.of("input.txt"))) {
            for (String word : line.toLowerCase().split("\\W+"))
                if (!word.isEmpty()) counts.put(word, counts.getOrDefault(word, 0) + 1);
        }
        counts.entrySet().stream().max(Map.Entry.comparingByValue())
            .ifPresent(System.out::println);
    }
}
