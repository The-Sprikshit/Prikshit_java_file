package strings;

public class Q027 {
    public static void main(String[] args) {
        String s = "Java makes programming enjoyable";
        String[] words = s.split("\\s+");
        String smallest = words[0], largest = words[0];
        for (String word : words) {
            if (word.length() < smallest.length()) smallest = word;
            if (word.length() > largest.length()) largest = word;
        }
        System.out.println("Smallest: " + smallest + ", largest: " + largest);
    }
}
