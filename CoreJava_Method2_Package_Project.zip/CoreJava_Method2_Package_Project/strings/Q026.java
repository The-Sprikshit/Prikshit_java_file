package strings;

import java.util.*;
public class Q026 {
    public static void main(String[] args) {
        String s = "hello";
        Map<Character, Integer> counts = new LinkedHashMap<>();
        for (char ch : s.toCharArray()) counts.put(ch, counts.getOrDefault(ch, 0) + 1);
        System.out.println(counts);
    }
}
