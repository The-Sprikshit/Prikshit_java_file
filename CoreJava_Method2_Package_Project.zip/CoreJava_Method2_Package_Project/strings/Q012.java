package strings;

import java.util.Arrays;
public class Q012 {
    public static void main(String[] args) {
        String csv = "red,green,blue";
        String[] colors = csv.split(",");
        System.out.println(Arrays.toString(colors));
    }
}
