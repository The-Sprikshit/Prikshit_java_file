package strings;

public class Q021 {
    static void permute(String s, String prefix) {
        if (s.isEmpty()) { System.out.println(prefix); return; }
        for (int i = 0; i < s.length(); i++)
            permute(s.substring(0, i) + s.substring(i + 1),
                    prefix + s.charAt(i));
    }
    public static void main(String[] args) { permute("ABC", ""); }
}
