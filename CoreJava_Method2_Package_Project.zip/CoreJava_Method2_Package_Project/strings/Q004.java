package strings;

public class Q004 {
    public static void main(String[] args) {
        String s = "banana";
        char remove = 'a';
        System.out.println(s.replace(String.valueOf(remove), ""));
    }
}
