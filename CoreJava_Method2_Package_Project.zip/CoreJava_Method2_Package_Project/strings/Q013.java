package strings;

public class Q013 {
    static int countWords(String s) {
        if (s == null || s.trim().isEmpty()) return 0;
        return s.trim().split("\\s+").length;
    }
    public static void main(String[] args) {
        System.out.println(countWords("Java is fun"));
    }
}
