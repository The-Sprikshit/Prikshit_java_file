package strings;

public class Q037 {
    public static void main(String[] args) {
        String s = " Java   is\tfun ";
        System.out.println(s.replaceAll("\\s+", ""));
    }
}
