package strings;

import java.util.*;
public class Q025 {
    public static void main(String[] args) {
        String s = "java is fun and java is popular";
        Map<String, Integer> counts = new LinkedHashMap<>();
        for (String word : s.toLowerCase().split("\\W+"))
            counts.put(word, counts.getOrDefault(word, 0) + 1);
        counts.forEach((word, n) -> { if (n > 1) System.out.println(word + ": " + n); });
    }
}
