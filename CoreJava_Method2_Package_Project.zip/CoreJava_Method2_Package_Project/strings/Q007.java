package strings;

public class Q007 {
    public static void main(String[] args) {
        String s = "Jav";
        char ch = 'a';
        System.out.println(s + ch);
    }
}
