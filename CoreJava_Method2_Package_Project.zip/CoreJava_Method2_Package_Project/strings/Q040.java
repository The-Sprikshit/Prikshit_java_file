package strings;

public class Q040 {
    public static void main(String[] args) {
        String s = "Java";
        for (char ch : s.toCharArray()) System.out.println(ch);
    }
}
