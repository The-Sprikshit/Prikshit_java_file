package strings;

public class Q015 {
    public static void main(String[] args) {
        String s = "Hello, Java! How are you?";
        int count = 0;
        for (char ch : s.toCharArray()) {
            int type = Character.getType(ch);
            if (type == Character.CONNECTOR_PUNCTUATION ||
                type == Character.DASH_PUNCTUATION ||
                type == Character.START_PUNCTUATION ||
                type == Character.END_PUNCTUATION ||
                type == Character.OTHER_PUNCTUATION ||
                type == Character.INITIAL_QUOTE_PUNCTUATION ||
                type == Character.FINAL_QUOTE_PUNCTUATION) count++;
        }
        System.out.println(count);
    }
}
