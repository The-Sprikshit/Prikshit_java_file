package strings;

import java.util.Scanner;
public class Q044 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String first = sc.nextLine();
        String second = sc.nextLine();
        System.out.println(first.contains(second));
        sc.close();
    }
}
