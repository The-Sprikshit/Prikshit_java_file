package strings;

public class Q001 {
    public static void main(String[] args) {
        String s = "123450";
        System.out.println(s.matches("\\d+"));
    }
}
