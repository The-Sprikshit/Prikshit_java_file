package strings;

public class Q032 {
    public static void main(String[] args) {
        String s = "HelloWorld";
        int index = 5;
        String result = s.substring(0, index) + " Java " + s.substring(index);
        System.out.println(result);
    }
}
