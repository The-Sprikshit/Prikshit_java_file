package strings;

public class Q031 {
    public static void main(String[] args) {
        String s = "Java";
        int index = 2;
        if (index >= 0 && index < s.length())
            System.out.println(s.charAt(index));
    }
}
