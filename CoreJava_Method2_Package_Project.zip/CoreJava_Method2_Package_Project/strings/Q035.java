package strings;

public class Q035 {
    public static void main(String[] args) {
        String s = "Java is easy to learn";
        for (String word : s.split("\\s+"))
            if (word.length() % 2 == 0) System.out.println(word);
    }
}
