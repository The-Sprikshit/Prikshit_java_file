package strings;

public class Q005 {
    public static void main(String[] args) {
        StringBuffer sb = new StringBuffer("Core");
        sb.append(" Java");
        System.out.println(sb);
    }
}
