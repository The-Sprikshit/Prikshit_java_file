package strings;

public class Q002 {
    public static void main(String[] args) {
        String original = new String("Hello Java");
        String copy = new String(original);
        System.out.println(copy);
        System.out.println(original == copy); // false
        System.out.println(original.equals(copy)); // true
    }
}
