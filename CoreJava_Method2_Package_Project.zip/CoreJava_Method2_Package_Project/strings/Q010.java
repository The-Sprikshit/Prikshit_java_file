package strings;

public class Q010 {
    public static void main(String[] args) {
        String s = "Level";
        String reversed = new StringBuilder(s).reverse().toString();
        System.out.println(s.equalsIgnoreCase(reversed));
    }
}
