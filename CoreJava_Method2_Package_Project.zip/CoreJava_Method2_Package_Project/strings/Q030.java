package strings;

import java.nio.file.*;
import java.io.IOException;
public class Q030 {
    public static void main(String[] args) throws IOException {
        long count = 0;
        for (String line : Files.readAllLines(Path.of("input.txt")))
            if (!line.trim().isEmpty()) count += line.trim().split("\\s+").length;
        System.out.println("Words: " + count);
    }
}
