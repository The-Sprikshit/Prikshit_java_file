package strings;

public class Q042 {
    public static void main(String[] args) {
        String a = "Hello", b = "Java";
        a = a + b;
        b = a.substring(0, a.length() - b.length());
        a = a.substring(b.length());
        System.out.println("a=" + a + ", b=" + b);
    }
}
