package inputoutput;

import java.util.Scanner;

public class Q005 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        double value = sc.nextDouble();
        System.out.println("Double: " + value);
        sc.close();
    }
}
