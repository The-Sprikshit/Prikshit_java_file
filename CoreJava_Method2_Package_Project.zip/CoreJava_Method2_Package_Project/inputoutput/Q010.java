package inputoutput;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

public class Q010 {
    public static void main(String[] args) throws IOException {
        String text = Files.readString(Path.of("input.txt"));
        long lines = text.isEmpty() ? 0 : text.lines().count();
        String trimmed = text.trim();
        long words = trimmed.isEmpty() ? 0 : trimmed.split("\\s+").length;
        int characters = text.length();
        System.out.println("Lines: " + lines);
        System.out.println("Words: " + words);
        System.out.println("Characters: " + characters);
        System.out.println("Content:");
        System.out.print(text);
    }
}
