package inputoutput;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

public class Q009 {
    public static void main(String[] args) throws IOException {
        Path path = Path.of("input.txt");
        String content = Files.readString(path);
        System.out.print(content);
    }
}
