package inputoutput;

import java.util.Scanner;

public class Q003 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int value = sc.nextInt();
        System.out.println("Integer: " + value);
        sc.close();
    }
}
