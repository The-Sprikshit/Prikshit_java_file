package inputoutput;

import java.util.Scanner;

public class Q004 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        float value = sc.nextFloat();
        System.out.println("Float: " + value);
        sc.close();
    }
}
