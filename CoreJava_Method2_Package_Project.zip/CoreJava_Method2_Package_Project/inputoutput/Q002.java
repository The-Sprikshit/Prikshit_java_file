package inputoutput;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;

public class Q002 {
    public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        String text = reader.readLine();
        System.out.println(text);
    }
}
