package inputoutput;

import java.io.InputStreamReader;
import java.io.IOException;

public class Q001 {
    public static void main(String[] args) throws IOException {
        InputStreamReader reader = new InputStreamReader(System.in);
        int value = reader.read();
        if (value != -1) System.out.println((char) value);
    }
}
