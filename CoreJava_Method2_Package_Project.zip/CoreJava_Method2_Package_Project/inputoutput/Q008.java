package inputoutput;

import java.util.Scanner;

public class Q008 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        long value = sc.nextLong();
        System.out.println("Long: " + value);
        sc.close();
    }
}
