package inputoutput;

import java.util.Scanner;

public class Q007 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        short value = sc.nextShort();
        System.out.println("Short: " + value);
        sc.close();
    }
}
