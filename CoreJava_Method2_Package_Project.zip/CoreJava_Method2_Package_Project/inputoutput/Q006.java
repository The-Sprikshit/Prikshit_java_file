package inputoutput;

import java.util.Scanner;

public class Q006 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        boolean value = sc.nextBoolean();
        System.out.println("Boolean: " + value);
        sc.close();
    }
}
