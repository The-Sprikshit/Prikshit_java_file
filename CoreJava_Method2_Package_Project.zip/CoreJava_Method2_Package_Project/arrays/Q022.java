package arrays;

public class Q022 {
    public static void main(String[] args) {
        int[] arr = {1, 2, 3, 4, 5, 6};
        System.out.print("Even: ");
        for (int value : arr) if (value % 2 == 0) System.out.print(value + " ");
        System.out.print("\nOdd: ");
        for (int value : arr) if (value % 2 != 0) System.out.print(value + " ");
    }
}
