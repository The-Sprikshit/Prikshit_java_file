package arrays;

public class Q010 {
    public static void main(String[] args) {
        int[] arr = {12, 5, 31, 8, 19};
        int smallest = arr[0];
        for (int value : arr) {
            if (value < smallest) smallest = value;
        }
        System.out.println("Smallest: " + smallest);
    }
}
