package arrays;

public class Q005 {
    public static void main(String[] args) {
        int[] arr = {10, 20, 30, 40};
        for (int value : arr) {
            System.out.println(value);
        }
    }
}
