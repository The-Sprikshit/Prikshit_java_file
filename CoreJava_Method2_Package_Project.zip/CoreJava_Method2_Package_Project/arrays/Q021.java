package arrays;

import java.util.Arrays;

public class Q021 {
    public static void main(String[] args) {
        int[] arr = {4, 2, 4, 7, 2, 9};
        int[] unique = Arrays.stream(arr).distinct().toArray();
        System.out.println(Arrays.toString(unique));
    }
}
