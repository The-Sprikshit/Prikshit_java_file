package arrays;

import java.util.Arrays;

public class Q019 {
    public static void main(String[] args) {
        int[] arr = {12, 5, 31, 8, 19, 5};
        int[] unique = Arrays.stream(arr).distinct().toArray();
        Arrays.sort(unique);
        if (unique.length < 2) {
            System.out.println("Fewer than 2 distinct values");
        } else {
            System.out.println("2nd smallest: " + unique[1]);
        }
    }
}
