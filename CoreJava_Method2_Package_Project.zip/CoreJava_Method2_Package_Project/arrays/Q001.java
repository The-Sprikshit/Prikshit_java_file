package arrays;

import java.util.Arrays;

public class Q001 {
    public static void main(String[] args) {
        int[] source = {10, 20, 30, 40};
        int[] copy = Arrays.copyOf(source, source.length);
        System.out.println(Arrays.toString(copy));
    }
}
