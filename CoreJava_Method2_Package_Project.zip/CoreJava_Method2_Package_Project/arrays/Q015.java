package arrays;

import java.util.Arrays;
import java.util.Collections;

public class Q015 {
    public static void main(String[] args) {
        Integer[] arr = {5, 2, 9, 1, 6};
        Arrays.sort(arr, Collections.reverseOrder());
        System.out.println(Arrays.toString(arr));
    }
}
