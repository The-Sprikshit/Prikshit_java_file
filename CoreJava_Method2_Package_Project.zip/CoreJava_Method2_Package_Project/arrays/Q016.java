package arrays;

import java.util.Arrays;

public class Q016 {
    public static void main(String[] args) {
        int[] arr = {12, 5, 31, 8, 19, 31};
        int[] unique = Arrays.stream(arr).distinct().toArray();
        Arrays.sort(unique);
        if (unique.length < 3) {
            System.out.println("Fewer than 3 distinct values");
        } else {
            System.out.println("3rd largest: " + unique[unique.length - 3]);
        }
    }
}
