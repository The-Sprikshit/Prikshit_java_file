package arrays;

import java.util.Arrays;

public class Q014 {
    public static void main(String[] args) {
        int[] arr = {5, 2, 9, 1, 6};
        Arrays.sort(arr);
        System.out.println(Arrays.toString(arr));
    }
}
