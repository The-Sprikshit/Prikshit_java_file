package arrays;

public class Q011 {
    public static void main(String[] args) {
        int[] arr = {12, 5, 31, 8, 19};
        System.out.println("Number of elements: " + arr.length);
    }
}
