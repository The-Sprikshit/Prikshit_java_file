package arrays;

import java.util.HashSet;
import java.util.Set;

public class Q004 {
    public static void main(String[] args) {
        int[] arr = {4, 2, 7, 2, 4, 9};
        Set<Integer> seen = new HashSet<>();
        Set<Integer> duplicates = new HashSet<>();
        for (int value : arr) {
            if (!seen.add(value)) duplicates.add(value);
        }
        System.out.println(duplicates);
    }
}
