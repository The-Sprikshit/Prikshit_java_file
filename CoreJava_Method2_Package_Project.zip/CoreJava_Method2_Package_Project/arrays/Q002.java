package arrays;

import java.util.HashMap;
import java.util.Map;

public class Q002 {
    public static void main(String[] args) {
        int[] arr = {2, 3, 2, 5, 3, 2};
        Map<Integer, Integer> frequency = new HashMap<>();
        for (int value : arr) {
            frequency.put(value, frequency.getOrDefault(value, 0) + 1);
        }
        frequency.forEach((key, count) ->
            System.out.println(key + " occurs " + count + " time(s)"));
    }
}
