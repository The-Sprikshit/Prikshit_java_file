package arrays;

public class Q009 {
    public static void main(String[] args) {
        int[] arr = {12, 5, 31, 8, 19};
        int largest = arr[0];
        for (int value : arr) {
            if (value > largest) largest = value;
        }
        System.out.println("Largest: " + largest);
    }
}
