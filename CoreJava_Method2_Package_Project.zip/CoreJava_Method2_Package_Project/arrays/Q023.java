package arrays;

import java.util.Arrays;

public class Q023 {
    public static void main(String[] args) {
        int[] numbers = {9, 3, 7, 1, 5};
        Arrays.sort(numbers);
        System.out.println(Arrays.toString(numbers));
    }
}
