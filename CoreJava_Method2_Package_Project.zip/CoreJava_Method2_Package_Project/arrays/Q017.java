package arrays;

import java.util.Arrays;

public class Q017 {
    public static void main(String[] args) {
        int[] arr = {12, 5, 31, 8, 19, 31};
        int[] unique = Arrays.stream(arr).distinct().toArray();
        Arrays.sort(unique);
        if (unique.length < 2) {
            System.out.println("Fewer than 2 distinct values");
        } else {
            System.out.println("2nd largest: " + unique[unique.length - 2]);
        }
    }
}
