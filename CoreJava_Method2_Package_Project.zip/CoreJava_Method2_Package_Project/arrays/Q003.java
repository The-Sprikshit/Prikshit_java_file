package arrays;

import java.util.Arrays;

public class Q003 {
    public static void main(String[] args) {
        int[] arr = {1, 2, 3, 4, 5};
        int k = 2, n = arr.length;
        k %= n;
        int[] rotated = new int[n];
        for (int i = 0; i < n; i++) {
            rotated[i] = arr[(i + k) % n];
        }
        System.out.println(Arrays.toString(rotated));
    }
}
