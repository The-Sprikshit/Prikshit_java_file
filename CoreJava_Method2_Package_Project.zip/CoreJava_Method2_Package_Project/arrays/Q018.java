package arrays;

import java.util.Arrays;

public class Q018 {
    public static void main(String[] args) {
        int[] arr = {12, 5, 31, 8, 19};
        System.out.println(Arrays.stream(arr).max().getAsInt());
    }
}
