package basicprogramming;

import java.util.Arrays; public class Q089 { public static void main(String[] args) { int[] a={4,1,3,2}; Arrays.sort(a); System.out.println(Arrays.toString(a)); } }
