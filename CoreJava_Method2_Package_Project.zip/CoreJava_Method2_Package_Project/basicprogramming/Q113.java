package basicprogramming;

public class Q113 { public static void main(String[] args) { int a=24,b=18,x=a,y=b; while(y!=0){int r=x%y;x=y;y=r;} int gcd=x; System.out.println("GCD="+gcd+" LCM="+(a/gcd*b)); } }
