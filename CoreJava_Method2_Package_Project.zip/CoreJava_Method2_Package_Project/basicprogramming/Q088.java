package basicprogramming;

public class Q088 { public static void main(String[] args) { int n=1234,rev=0; while(n!=0){rev=rev*10+n%10;n/=10;} System.out.println(rev); } }
