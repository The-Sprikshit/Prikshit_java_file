package basicprogramming;

public class Q112 { public static void main(String[] args) { int n=29; boolean p=n>=2; for(int d=2;d*d<=n;d++) if(n%d==0) p=false; System.out.println(p); } }
