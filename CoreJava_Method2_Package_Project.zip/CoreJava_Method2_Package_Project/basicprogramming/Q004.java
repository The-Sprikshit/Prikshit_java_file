package basicprogramming;

public class Q004 { public static void main(String[] args) { double a=12,b=5; System.out.println(a+b); System.out.println(a*b); System.out.println(a-b); System.out.println(a/b); System.out.println(a%b); } }
