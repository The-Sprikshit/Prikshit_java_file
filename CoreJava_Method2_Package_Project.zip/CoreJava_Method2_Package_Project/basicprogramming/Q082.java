package basicprogramming;

public class Q082 { public static void main(String[] args) { int[] a={2,4,6}; int s=0; for(int n:a)s+=n; System.out.println(s); } }
