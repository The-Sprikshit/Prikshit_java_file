package basicprogramming;

import java.time.LocalDateTime; public class Q076 { public static void main(String[] args) { System.out.println(LocalDateTime.now()); } }
