package basicprogramming;

public class Q070 { public static void main(String[] args) { System.out.println("Core JAVA".toLowerCase()); } }
