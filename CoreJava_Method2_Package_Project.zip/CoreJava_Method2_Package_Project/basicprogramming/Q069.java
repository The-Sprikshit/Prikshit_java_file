package basicprogramming;

public class Q069 { public static void main(String[] args) { System.out.println("Core"+" Java"); } }
