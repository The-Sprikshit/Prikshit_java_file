package basicprogramming;

public class Q086 { public static void main(String[] args) { int[] a={4,9,-2,7}; int min=a[0],max=a[0]; for(int n:a){min=Math.min(min,n);max=Math.max(max,n);} System.out.println(min+" "+max); } }
