package basicprogramming;

public class Q084 { public static void main(String[] args) { int[] a={10,20,30}; int sum=0; for(int n:a)sum+=n; System.out.println(sum/(double)a.length); } }
