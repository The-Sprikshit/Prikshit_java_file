package basicprogramming;

public class Q083 { public static void main(String[] args) { int[] a={3,8,2,9}; int key=2, index=-1; for(int i=0;i<a.length;i++) if(a[i]==key){index=i;break;} System.out.println(index); } }
