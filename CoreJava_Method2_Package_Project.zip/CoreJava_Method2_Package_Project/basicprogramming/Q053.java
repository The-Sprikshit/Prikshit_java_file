package basicprogramming;

import java.time.YearMonth; public class Q053 { public static void main(String[] args) { System.out.println(YearMonth.of(2028,2).lengthOfMonth()); } }
