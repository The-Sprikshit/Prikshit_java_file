package basicprogramming;

public class Q029 { public static void main(String[] args) { double b=10,h=6; System.out.println(b*h/2); } }
