package basicprogramming;

public class Q003 { public static void main(String[] args) { int a=6, b=7; System.out.println(a*b); } }
