package basicprogramming;

import java.time.LocalDateTime; public class Q015 { public static void main(String[] args) { System.out.println(LocalDateTime.now()); } }
