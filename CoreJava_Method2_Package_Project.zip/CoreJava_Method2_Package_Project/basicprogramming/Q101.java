package basicprogramming;

import java.util.Arrays; public class Q101 { public static void main(String[] args) { int[] a={4,1,3,2}; Arrays.sort(a); System.out.println(Arrays.toString(a)); } }
