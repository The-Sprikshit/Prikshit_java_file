package basicprogramming;

public class Q136 { public static void main(String[] args) { int a=10,b=3; System.out.println((a+b-1)/b); } }
