package basicprogramming;

public class Q071 { public static void main(String[] args) { System.out.println("Core Java".toUpperCase()); } }
