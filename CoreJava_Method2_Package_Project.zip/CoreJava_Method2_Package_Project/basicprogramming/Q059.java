package basicprogramming;

public class Q059 { public static void main(String[] args) { char c='e'; System.out.println("aeiouAEIOU".indexOf(c)>=0 ? "Vowel" : "Not a vowel"); } }
