package basicprogramming;

public class Q018 { public static void main(String[] args) { String s="1234"; int n=Integer.parseInt(s); System.out.println(n); } }
