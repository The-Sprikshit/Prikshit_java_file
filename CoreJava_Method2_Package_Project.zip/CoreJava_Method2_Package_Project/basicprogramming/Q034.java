package basicprogramming;

public class Q034 { public static void main(String[] args) { double r=3; System.out.println(4.0/3*Math.PI*r*r*r); } }
