package basicprogramming;

public class Q027 { public static void main(String[] args) { double r=5; System.out.println(Math.PI*r*r); } }
