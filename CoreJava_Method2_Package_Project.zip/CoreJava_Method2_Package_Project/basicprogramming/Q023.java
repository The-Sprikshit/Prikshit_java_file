package basicprogramming;

public class Q023 { public static void main(String[] args) { System.out.println(Math.sqrt(81)); } }
