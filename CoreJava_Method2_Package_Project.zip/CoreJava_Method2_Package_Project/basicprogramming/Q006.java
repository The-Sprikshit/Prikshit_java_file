package basicprogramming;

public class Q006 { public static void main(String[] args) { int a=10,b=20,temp=a; a=b; b=temp; System.out.println(a+" "+b); } }
