package basicprogramming;

public class Q002 { public static void main(String[] args) { int a=12, b=8; System.out.println(a+b); } }
