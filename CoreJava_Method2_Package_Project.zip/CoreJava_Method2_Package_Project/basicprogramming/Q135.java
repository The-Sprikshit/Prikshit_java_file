package basicprogramming;

public class Q135 { public static void main(String[] args) { double x=12.0; System.out.println(x==Math.rint(x)); } }
