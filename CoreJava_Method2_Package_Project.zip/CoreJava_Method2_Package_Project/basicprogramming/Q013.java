package basicprogramming;

public class Q013 { public static void main(String[] args) { char ch='A'; System.out.println((int)ch); } }
