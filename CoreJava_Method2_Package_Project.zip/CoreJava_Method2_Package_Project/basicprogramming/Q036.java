package basicprogramming;

public class Q036 { public static void main(String[] args) { double l=5,w=3,h=2; System.out.println(l*w*h); } }
