package basicprogramming;

public class Q075 { public static void main(String[] args) { System.out.println("Java".length()); } }
