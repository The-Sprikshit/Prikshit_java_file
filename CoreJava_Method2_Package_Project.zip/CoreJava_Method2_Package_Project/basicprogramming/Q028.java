package basicprogramming;

public class Q028 { public static void main(String[] args) { double l=8,w=4; System.out.println(l*w); } }
