package basicprogramming;

public class Q051 { public static void main(String[] args) { System.out.println(Math.pow(2,8)); } }
