package basicprogramming;

public class Q008 { public static void main(String[] args) { System.out.println(Integer.parseInt("11001",2)); } }
