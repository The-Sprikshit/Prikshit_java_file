package basicprogramming;

public class Q063 { public static void main(String[] args) { int n=-4; System.out.println(n>0?"Positive":n<0?"Negative":"Zero"); } }
