package basicprogramming;

public class Q046 { public static void main(String[] args) { int n=12; System.out.println(n); } }
