package basicprogramming;

public class Q019 { public static void main(String[] args) { int s=3672; System.out.printf("%d:%02d:%02d%n",s/3600,(s%3600)/60,s%60); } }
