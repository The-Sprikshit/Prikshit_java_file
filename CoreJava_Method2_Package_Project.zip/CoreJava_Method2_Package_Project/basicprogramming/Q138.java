package basicprogramming;

public class Q138 { public static void main(String[] args) { float x=-12.5f; System.out.println(Math.abs(x)); } }
