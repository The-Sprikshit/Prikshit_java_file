package basicprogramming;

public class Q001 { public static void main(String[] args) { System.out.println("Hello World!"); } }
