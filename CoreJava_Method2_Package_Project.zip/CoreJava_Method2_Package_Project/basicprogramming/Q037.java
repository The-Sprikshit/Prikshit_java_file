package basicprogramming;

public class Q037 { public static void main(String[] args) { double r=3,h=7; System.out.println(Math.PI*r*r*h/3); } }
