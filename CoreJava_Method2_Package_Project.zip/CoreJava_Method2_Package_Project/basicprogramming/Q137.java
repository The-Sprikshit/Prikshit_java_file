package basicprogramming;

public class Q137 { public static void main(String[] args) { System.out.println(1994); } }
