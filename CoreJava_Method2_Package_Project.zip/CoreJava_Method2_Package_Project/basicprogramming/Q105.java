package basicprogramming;

public class Q105 { public static void main(String[] args) { int n=12; System.out.println(n); } }
