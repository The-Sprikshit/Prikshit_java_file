package basicprogramming;

public class Q056 { public static void main(String[] args) { int y=2028; System.out.println(y%400==0 || (y%4==0 && y%100!=0)); } }
