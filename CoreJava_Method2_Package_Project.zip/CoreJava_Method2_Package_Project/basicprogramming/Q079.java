package basicprogramming;

public class Q079 { public static void main(String[] args) { System.out.println(new StringBuilder("Java").reverse()); } }
