package basicprogramming;

public class Q134 { public static void main(String[] args) { double x=12.34567; System.out.printf("%.2f%n",x); } }
