package basicprogramming;

public class Q072 { public static void main(String[] args) { System.out.println("  hello Java  ".trim()); } }
