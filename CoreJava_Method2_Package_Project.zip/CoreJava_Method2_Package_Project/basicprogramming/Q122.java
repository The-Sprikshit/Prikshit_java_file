package basicprogramming;

public class Q122 { public static void main(String[] args) { String s="Core Java practice"; System.out.println(s); } }
