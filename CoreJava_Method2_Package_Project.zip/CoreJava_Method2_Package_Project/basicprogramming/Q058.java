package basicprogramming;

public class Q058 { public static void main(String[] args) { int n=12; System.out.println(n); } }
