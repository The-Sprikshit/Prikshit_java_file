package basicprogramming;

public class Q007 { public static void main(String[] args) { System.out.println(Integer.toBinaryString(25)); } }
