package interfaces;

interface Q006Helper1 { void draw(); }
class Q006Helper2 implements Q006Helper1 {
    public void draw() { System.out.println("Drawing a circle"); }
}
class Q006Helper3 implements Q006Helper1 {
    public void draw() { System.out.println("Drawing a rectangle"); }
}
class Q006Helper4 implements Q006Helper1 {
    public void draw() { System.out.println("Drawing a triangle"); }
}
public class Q006 {
    public static void main(String[] args) {
        Q006Helper1[] shapes = {new Q006Helper2(), new Q006Helper3(), new Q006Helper4()};
        for (Q006Helper1 shape : shapes) shape.draw();
    }
}
