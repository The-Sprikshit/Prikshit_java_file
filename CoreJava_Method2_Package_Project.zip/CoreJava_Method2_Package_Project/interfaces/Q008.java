package interfaces;

interface Q008Helper1 { void play(); }
class Q008Helper2 implements Q008Helper1 {
    public void play() { System.out.println("Playing football"); }
}
class Q008Helper3 implements Q008Helper1 {
    public void play() { System.out.println("Playing volleyball"); }
}
class Q008Helper4 implements Q008Helper1 {
    public void play() { System.out.println("Playing basketball"); }
}
public class Q008 {
    public static void main(String[] args) {
        Q008Helper1[] games = {new Q008Helper2(), new Q008Helper3(), new Q008Helper4()};
        for (Q008Helper1 game : games) game.play();
    }
}
