package interfaces;

interface Q005Helper1 {
    void resizeWidth(int width);
    void resizeHeight(int height);
}
class Q005Helper2 implements Q005Helper1 {
    private int width, height;
    Q005Helper2(int width, int height) { this.width = width; this.height = height; }
    public void resizeWidth(int width) { if (width > 0) this.width = width; }
    public void resizeHeight(int height) { if (height > 0) this.height = height; }
    public String toString() { return width + " x " + height; }
}
public class Q005 {
    public static void main(String[] args) {
        Q005Helper2 r = new Q005Helper2(4, 3);
        r.resizeWidth(8);
        r.resizeHeight(6);
        System.out.println(r);
    }
}
