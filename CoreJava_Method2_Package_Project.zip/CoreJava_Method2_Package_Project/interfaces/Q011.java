package interfaces;

import java.util.Arrays;
interface Q011Helper1 { void sort(int[] array); }
class Q011Helper2 implements Q011Helper1 {
    public void sort(int[] a) { quick(a, 0, a.length - 1); }
    private void quick(int[] a, int low, int high) {
        if (low >= high) return;
        int i = low, j = high, pivot = a[(low + high) / 2];
        while (i <= j) {
            while (a[i] > pivot) i++;
            while (a[j] < pivot) j--;
            if (i <= j) { int t=a[i]; a[i]=a[j]; a[j]=t; i++; j--; }
        }
        if (low < j) quick(a, low, j);
        if (i < high) quick(a, i, high);
    }
}
class Q011Helper3 implements Q011Helper1 {
    public void sort(int[] a) { if (a.length > 1) mergeSort(a, 0, a.length - 1); }
    private void mergeSort(int[] a, int l, int r) {
        if (l >= r) return;
        int m = (l + r) / 2;
        mergeSort(a, l, m); mergeSort(a, m + 1, r);
        int[] tmp = new int[r - l + 1]; int i=l, j=m+1, k=0;
        while (i<=m && j<=r) tmp[k++] = a[i] >= a[j] ? a[i++] : a[j++];
        while (i<=m) tmp[k++] = a[i++];
        while (j<=r) tmp[k++] = a[j++];
        System.arraycopy(tmp, 0, a, l, tmp.length);
    }
}
public class Q011 {
    public static void main(String[] args) {
        int[] a={5, 1, 9, 3}, b={8, 2, 6, 4};
        new Q011Helper2().sort(a); new Q011Helper3().sort(b);
        System.out.println(Arrays.toString(a));
        System.out.println(Arrays.toString(b));
    }
}
