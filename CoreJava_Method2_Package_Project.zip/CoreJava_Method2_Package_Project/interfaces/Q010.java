package interfaces;

interface Q010Helper1 {
    String encrypt(String data);
    String decrypt(String encryptedData);
}
class Q010Helper2 implements Q010Helper1 {
    public String encrypt(String data) {
        return "[AES demo placeholder: " + data + "]";
    }
    public String decrypt(String encryptedData) {
        return encryptedData.replace("[AES demo placeholder: ", "").replace("]", "");
    }
}
class Q010Helper3 implements Q010Helper1 {
    public String encrypt(String data) {
        return "[RSA demo placeholder: " + data + "]";
    }
    public String decrypt(String encryptedData) {
        return encryptedData.replace("[RSA demo placeholder: ", "").replace("]", "");
    }
}
public class Q010 {
    public static void main(String[] args) {
        Q010Helper1 aes = new Q010Helper2();
        String encrypted = aes.encrypt("hello");
        System.out.println(encrypted);
        System.out.println(aes.decrypt(encrypted));
    }
}
