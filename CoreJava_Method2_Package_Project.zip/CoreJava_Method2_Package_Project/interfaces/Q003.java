package interfaces;

interface Q003Helper1 { void fly_obj(); }
class Q003Helper2 implements Q003Helper1 {
    public void fly_obj() { System.out.println("Spacecraft travels beyond Earth"); }
}
class Q003Helper3 implements Q003Helper1 {
    public void fly_obj() { System.out.println("Airplane flies using wings"); }
}
class Q003Helper4 implements Q003Helper1 {
    public void fly_obj() { System.out.println("Helicopter flies using rotors"); }
}
public class Q003 {
    public static void main(String[] args) {
        Q003Helper1[] vehicles = {new Q003Helper2(), new Q003Helper3(), new Q003Helper4()};
        for (Q003Helper1 vehicle : vehicles) vehicle.fly_obj();
    }
}
