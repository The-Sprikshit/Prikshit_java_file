package interfaces;

import java.util.Arrays;
interface Q007Helper1 { void sort(); int[] getArray(); }
class Q007Helper2 implements Q007Helper1 {
    private final int[] a;
    Q007Helper2(int[] values) { a = values.clone(); }
    public void sort() {
        for (int i = 0; i < a.length - 1; i++)
            for (int j = 0; j < a.length - i - 1; j++)
                if (a[j] > a[j + 1]) {
                    int t = a[j]; a[j] = a[j + 1]; a[j + 1] = t;
                }
    }
    public int[] getArray() { return a; }
}
class Q007Helper3 implements Q007Helper1 {
    private final int[] a;
    Q007Helper3(int[] values) { a = values.clone(); }
    public void sort() {
        for (int i = 0; i < a.length - 1; i++) {
            int min = i;
            for (int j = i + 1; j < a.length; j++)
                if (a[j] < a[min]) min = j;
            int t = a[i]; a[i] = a[min]; a[min] = t;
        }
    }
    public int[] getArray() { return a; }
}
public class Q007 {
    public static void main(String[] args) {
        Q007Helper1 first = new Q007Helper2(new int[]{5, 1, 4, 2});
        Q007Helper1 second = new Q007Helper3(new int[]{8, 3, 6, 1});
        first.sort(); second.sort();
        System.out.println(Arrays.toString(first.getArray()));
        System.out.println(Arrays.toString(second.getArray()));
    }
}
