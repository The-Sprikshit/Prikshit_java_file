package interfaces;

interface Q009Helper1 { boolean search(String keyword); }
class Q009Helper2 implements Q009Helper1 {
    private final String text;
    Q009Helper2(String text) { this.text = text; }
    public boolean search(String keyword) {
        return keyword != null && text.toLowerCase().contains(keyword.toLowerCase());
    }
}
class Q009Helper3 implements Q009Helper1 {
    private final String title, body;
    Q009Helper3(String title, String body) { this.title = title; this.body = body; }
    public boolean search(String keyword) {
        return keyword != null &&
            (title.toLowerCase().contains(keyword.toLowerCase()) ||
             body.toLowerCase().contains(keyword.toLowerCase()));
    }
}
public class Q009 {
    public static void main(String[] args) {
        Q009Helper1 doc = new Q009Helper2("Java interfaces define contracts.");
        Q009Helper1 page = new Q009Helper3("Learning Java", "Classes implement interfaces.");
        System.out.println(doc.search("contracts"));
        System.out.println(page.search("interfaces"));
    }
}
