package interfaces;

interface Q002Helper1 { void bark(); }
class Q002Helper2 implements Q002Helper1 {
    @Override
    public void bark() { System.out.println("Dog is barking"); }
}
public class Q002 {
    public static void main(String[] args) {
        Q002Helper1 animal = new Q002Helper2();
        animal.bark();
    }
}
