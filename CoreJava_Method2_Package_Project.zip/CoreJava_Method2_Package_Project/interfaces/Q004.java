package interfaces;

import java.util.*;
interface Q004Helper1 {
    void deposit(double amount);
    boolean withdraw(double amount);
    double calculateInterest();
    double getBalance();
}
class Q004Helper2 implements Q004Helper1 {
    private double balance;
    Q004Helper2(double initial) { balance = initial; }
    public void deposit(double amount) { if (amount > 0) balance += amount; }
    public boolean withdraw(double amount) {
        if (amount > 0 && amount <= balance) { balance -= amount; return true; }
        return false;
    }
    public double calculateInterest() { return balance * 0.04; }
    public double getBalance() { return balance; }
    public void addAnnualBonus(double bonus) { if (bonus > 0) balance += bonus; }
}
class Q004Helper3 implements Q004Helper1 {
    private double balance;
    Q004Helper3(double initial) { balance = initial; }
    public void deposit(double amount) { if (amount > 0) balance += amount; }
    public boolean withdraw(double amount) {
        if (amount > 0 && amount <= balance) { balance -= amount; return true; }
        return false;
    }
    public double calculateInterest() { return 0; }
    public double getBalance() { return balance; }
    public void printAccountType() { System.out.println("Current account"); }
}
class Q004Helper4 {
    private final List<Q004Helper1> accounts = new ArrayList<>();
    public void addAccount(Q004Helper1 account) { accounts.add(account); }
    public void printBalances() {
        for (Q004Helper1 account : accounts)
            System.out.printf("Balance: %.2f, interest estimate: %.2f%n",
                    account.getBalance(), account.calculateInterest());
    }
}
public class Q004 {
    public static void main(String[] args) {
        Q004Helper4 bank = new Q004Helper4();
        Q004Helper2 savings = new Q004Helper2(1000);
        Q004Helper3 current = new Q004Helper3(500);
        savings.deposit(200);
        current.withdraw(100);
        bank.addAccount(savings);
        bank.addAccount(current);
        bank.printBalances();
    }
}
