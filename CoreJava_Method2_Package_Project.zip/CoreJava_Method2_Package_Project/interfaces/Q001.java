package interfaces;

interface Q001Helper1 { double getArea(); }
class Q001Helper2 implements Q001Helper1 {
    double width, height;
    Q001Helper2(double w, double h) { width = w; height = h; }
    public double getArea() { return width * height; }
}
class Q001Helper3 implements Q001Helper1 {
    double radius;
    Q001Helper3(double r) { radius = r; }
    public double getArea() { return Math.PI * radius * radius; }
}
class Q001Helper4 implements Q001Helper1 {
    double base, height;
    Q001Helper4(double b, double h) { base = b; height = h; }
    public double getArea() { return base * height / 2; }
}
public class Q001 {
    public static void main(String[] args) {
        Q001Helper1[] shapes = {new Q001Helper2(4, 5), new Q001Helper3(3), new Q001Helper4(6, 2)};
        for (Q001Helper1 shape : shapes) System.out.printf("%.2f%n", shape.getArea());
    }
}
