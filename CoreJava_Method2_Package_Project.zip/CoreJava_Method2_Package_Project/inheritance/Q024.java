package inheritance;

abstract class Q024Helper1 { abstract void draw(); abstract void resize(double factor); }
class Q024Helper2 extends Q024Helper1 { double w=4,h=3; void draw(){System.out.println("Rectangle "+w+" x "+h);} void resize(double f){w*=f;h*=f;} }
class Q024Helper3 extends Q024Helper1 { double r=2; void draw(){System.out.println("Circle radius "+r);} void resize(double f){r*=f;} }
public class Q024 { public static void main(String[] args){Q024Helper1[] s={new Q024Helper2(),new Q024Helper3()};for(Q024Helper1 x:s){x.draw();x.resize(2);x.draw();}} }
