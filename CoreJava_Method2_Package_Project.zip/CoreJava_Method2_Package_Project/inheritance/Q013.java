package inheritance;

class Q013Helper1 { void sound(){System.out.println("Generic sound");} }
class Q013Helper2 extends Q013Helper1 { @Override void sound(){System.out.println("Woof");} }
public class Q013 { public static void main(String[] args){Q013Helper1 a=new Q013Helper2();a.sound();} }
