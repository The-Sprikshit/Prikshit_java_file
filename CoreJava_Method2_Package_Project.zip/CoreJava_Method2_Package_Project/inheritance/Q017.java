package inheritance;

abstract class Q017Helper1 { protected double balance; Q017Helper1(double b){balance=b;} abstract void deposit(double a); abstract boolean withdraw(double a); }
class Q017Helper2 extends Q017Helper1 { Q017Helper2(double b){super(b);} void deposit(double a){if(a>0)balance+=a;} boolean withdraw(double a){if(a>0&&a<=balance){balance-=a;return true;}return false;} }
class Q017Helper3 extends Q017Helper1 { Q017Helper3(double b){super(b);} void deposit(double a){if(a>0)balance+=a;} boolean withdraw(double a){if(a>0&&a<=balance+500){balance-=a;return true;}return false;} }
public class Q017 { public static void main(String[] args){Q017Helper1 s=new Q017Helper2(1000),c=new Q017Helper3(200);s.deposit(100);c.withdraw(500);System.out.println(s.balance+" "+c.balance);} }
