package inheritance;

class Q010Helper1 {
    String name, address, jobTitle; double salary;
    Q010Helper1(String n,String a,double s,String j){name=n;address=a;salary=s;jobTitle=j;}
    double calculateBonus(){return salary*0.10;}
    void report(){System.out.println(name+" | "+jobTitle+" | bonus="+calculateBonus());}
}
class Q010Helper2 extends Q010Helper1 { Q010Helper2(String n){super(n,"Chandigarh",80000,"Manager");} void manageProject(){System.out.println("Managing project");} }
class Q010Helper3 extends Q010Helper1 { Q010Helper3(String n){super(n,"Mohali",60000,"Developer");} }
class Q010Helper4 extends Q010Helper1 { Q010Helper4(String n){super(n,"Panchkula",50000,"Programmer");} }
public class Q010 { public static void main(String[] args){Q010Helper1[] e={new Q010Helper2("Aman"),new Q010Helper3("Riya"),new Q010Helper4("Kabir")};for(Q010Helper1 x:e)x.report();} }
