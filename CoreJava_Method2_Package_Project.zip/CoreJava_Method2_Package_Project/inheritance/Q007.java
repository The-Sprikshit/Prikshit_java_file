package inheritance;

class Q007Helper1 {
    String getFirstName() { return "Aman"; }
    String getLastName() { return "Kumar"; }
}
class Q007Helper2 extends Q007Helper1 {
    private final String id = "E101";
    String getEmployeeId() { return id; }
    @Override String getLastName() { return super.getLastName() + " (Developer)"; }
}
public class Q007 { public static void main(String[] args) { Q007Helper2 e = new Q007Helper2(); System.out.println(e.getFirstName()+" "+e.getLastName()+" "+e.getEmployeeId()); } }
