package inheritance;

class Q003Helper1 { double getArea() { return 0; } }
class Q003Helper2 extends Q003Helper1 {
    double width, height;
    Q003Helper2(double w, double h) { width = w; height = h; }
    @Override double getArea() { return width * height; }
}
public class Q003 { public static void main(String[] args) { System.out.println(new Q003Helper2(4, 5).getArea()); } }
