package inheritance;

abstract class Q020Helper1 { abstract double calculateVolume(); abstract double calculateSurfaceArea(); }
class Q020Helper2 extends Q020Helper1 { double r; Q020Helper2(double r){this.r=r;} double calculateVolume(){return 4.0/3*Math.PI*r*r*r;} double calculateSurfaceArea(){return 4*Math.PI*r*r;} }
class Q020Helper3 extends Q020Helper1 { double side; Q020Helper3(double s){side=s;} double calculateVolume(){return side*side*side;} double calculateSurfaceArea(){return 6*side*side;} }
public class Q020 { public static void main(String[] args){Q020Helper1[] s={new Q020Helper2(2),new Q020Helper3(3)};for(Q020Helper1 x:s)System.out.println(x.calculateVolume()+" "+x.calculateSurfaceArea());} }
