package inheritance;

class Q006Helper1 { void move() { System.out.println("Animal moves"); } }
class Q006Helper2 extends Q006Helper1 { @Override void move() { System.out.println("Cheetah runs"); } }
public class Q006 { public static void main(String[] args) { new Q006Helper2().move(); } }
