package inheritance;

class Q008Helper1 { double getArea() { return 0; } double getPerimeter() { return 0; } }
class Q008Helper2 extends Q008Helper1 {
    double radius;
    Q008Helper2(double r) { radius = r; }
    @Override double getArea() { return Math.PI * radius * radius; }
    @Override double getPerimeter() { return 2 * Math.PI * radius; }
}
public class Q008 { public static void main(String[] args) { Q008Helper2 c = new Q008Helper2(3); System.out.println(c.getArea()); System.out.println(c.getPerimeter()); } }
