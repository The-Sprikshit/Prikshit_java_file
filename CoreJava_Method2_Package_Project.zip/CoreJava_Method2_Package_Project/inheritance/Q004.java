package inheritance;

class Q004Helper1 {
    void work() { System.out.println("Employee works"); }
    double getSalary() { return 40000; }
}
class Q004Helper2 extends Q004Helper1 {
    @Override void work() { System.out.println("HR manager manages people"); }
    void addEmployee(String name) { System.out.println("Added: " + name); }
}
public class Q004 { public static void main(String[] args) { Q004Helper2 h = new Q004Helper2(); h.work(); h.addEmployee("Aman"); System.out.println(h.getSalary()); } }
