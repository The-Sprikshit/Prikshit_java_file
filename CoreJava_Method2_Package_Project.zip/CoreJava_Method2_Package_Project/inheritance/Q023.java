package inheritance;

abstract class Q023Helper1 { abstract void play(); abstract void tune(); }
class Q023Helper2 extends Q023Helper1 { void play(){System.out.println("Playing glockenspiel");} void tune(){System.out.println("Check bars and mallets");} }
class Q023Helper3 extends Q023Helper1 { void play(){System.out.println("Playing violin");} void tune(){System.out.println("Tune strings");} }
public class Q023 { public static void main(String[] args){Q023Helper1[] i={new Q023Helper2(),new Q023Helper3()};for(Q023Helper1 x:i){x.play();x.tune();}} }
