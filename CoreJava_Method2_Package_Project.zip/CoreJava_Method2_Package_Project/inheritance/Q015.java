package inheritance;

abstract class Q015Helper1 { abstract void sound(); }
class Q015Helper2 extends Q015Helper1 { void sound(){System.out.println("Roar");} }
class Q015Helper3 extends Q015Helper1 { void sound(){System.out.println("Growl");} }
public class Q015 { public static void main(String[] args){Q015Helper1[] a={new Q015Helper2(),new Q015Helper3()};for(Q015Helper1 x:a)x.sound();} }
