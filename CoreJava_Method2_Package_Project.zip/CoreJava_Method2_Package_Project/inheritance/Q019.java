package inheritance;

abstract class Q019Helper1 { abstract double calculateSalary(); abstract void displayInfo(); }
class Q019Helper2 extends Q019Helper1 { double calculateSalary(){return 80000;} void displayInfo(){System.out.println("Manager salary="+calculateSalary());} }
class Q019Helper3 extends Q019Helper1 { double calculateSalary(){return 60000;} void displayInfo(){System.out.println("Programmer salary="+calculateSalary());} }
public class Q019 { public static void main(String[] args){new Q019Helper2().displayInfo();new Q019Helper3().displayInfo();} }
