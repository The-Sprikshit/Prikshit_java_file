package inheritance;

abstract class Q016Helper1 { abstract double calculateArea(); abstract double calculatePerimeter(); }
class Q016Helper2 extends Q016Helper1 {
    double r; Q016Helper2(double r){this.r=r;}
    double calculateArea(){return Math.PI*r*r;}
    double calculatePerimeter(){return 2*Math.PI*r;}
}
class Q016Helper3 extends Q016Helper1 {
    double a,b,c; Q016Helper3(double a,double b,double c){this.a=a;this.b=b;this.c=c;}
    double calculateArea(){double s=(a+b+c)/2;return Math.sqrt(s*(s-a)*(s-b)*(s-c));}
    double calculatePerimeter(){return a+b+c;}
}
public class Q016 { public static void main(String[] args){Q016Helper1 c=new Q016Helper2(3),t=new Q016Helper3(3,4,5);System.out.println(c.calculateArea()+" "+c.calculatePerimeter());System.out.println(t.calculateArea()+" "+t.calculatePerimeter());} }
