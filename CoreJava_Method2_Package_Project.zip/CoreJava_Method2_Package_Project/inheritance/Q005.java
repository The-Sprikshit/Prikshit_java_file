package inheritance;

class Q005Helper1 {
    protected double balance;
    void deposit(double amount) { if (amount > 0) balance += amount; }
    boolean withdraw(double amount) { if (amount > 0 && amount <= balance) { balance -= amount; return true; } return false; }
}
class Q005Helper2 extends Q005Helper1 {
    @Override boolean withdraw(double amount) {
        if (amount > 0 && balance - amount >= 100) { balance -= amount; return true; }
        return false;
    }
}
public class Q005 { public static void main(String[] args) { Q005Helper2 a = new Q005Helper2(); a.deposit(500); System.out.println(a.withdraw(450)); System.out.println(a.balance); } }
