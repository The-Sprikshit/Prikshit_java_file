package inheritance;

abstract class Q026Helper1 { abstract double area(); abstract double perimeter(); }
class Q026Helper2 extends Q026Helper1 { double a,b,c; Q026Helper2(double a,double b,double c){this.a=a;this.b=b;this.c=c;} double area(){double s=(a+b+c)/2;return Math.sqrt(s*(s-a)*(s-b)*(s-c));} double perimeter(){return a+b+c;} }
class Q026Helper3 extends Q026Helper1 { double side; Q026Helper3(double s){side=s;} double area(){return side*side;} double perimeter(){return 4*side;} }
public class Q026 { public static void main(String[] args){Q026Helper1[] g={new Q026Helper2(3,4,5),new Q026Helper3(4)};for(Q026Helper1 x:g)System.out.println(x.area()+" "+x.perimeter());} }
