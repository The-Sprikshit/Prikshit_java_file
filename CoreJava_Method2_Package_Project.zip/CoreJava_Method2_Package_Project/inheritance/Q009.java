package inheritance;

class Q009Helper1 {
    String make, model, fuelType; int year; double kmPerLitre, maxSpeed;
    Q009Helper1(String make, String model, int year, String fuelType, double efficiency, double speed) {
        this.make=make; this.model=model; this.year=year; this.fuelType=fuelType; kmPerLitre=efficiency; maxSpeed=speed;
    }
    double distanceForFuel(double litres) { return kmPerLitre * litres; }
}
class Q009Helper2 extends Q009Helper1 { Q009Helper2() { super("Tata","Truck",2024,"Diesel",5,100); } }
class Q009Helper3 extends Q009Helper1 { Q009Helper3() { super("Honda","City",2024,"Petrol",16,180); } }
class Q009Helper4 extends Q009Helper1 { Q009Helper4() { super("Honda","Bike",2024,"Petrol",40,120); } }
public class Q009 { public static void main(String[] args) { Q009Helper1[] v={new Q009Helper2(),new Q009Helper3(),new Q009Helper4()}; for(Q009Helper1 x:v) System.out.println(x.make+" "+x.model+" distance on 10L="+x.distanceForFuel(10)+" km, max="+x.maxSpeed); } }
