package inheritance;

abstract class Q018Helper1 { abstract void eat(); abstract void sleep(); }
class Q018Helper2 extends Q018Helper1 { void eat(){System.out.println("Lion eats meat");} void sleep(){System.out.println("Lion rests");} }
class Q018Helper3 extends Q018Helper1 { void eat(){System.out.println("Tiger hunts prey");} void sleep(){System.out.println("Tiger sleeps in cover");} }
class Q018Helper4 extends Q018Helper1 { void eat(){System.out.println("Deer grazes plants");} void sleep(){System.out.println("Deer rests alertly");} }
public class Q018 { public static void main(String[] args){Q018Helper1[] a={new Q018Helper2(),new Q018Helper3(),new Q018Helper4()};for(Q018Helper1 x:a){x.eat();x.sleep();}} }
