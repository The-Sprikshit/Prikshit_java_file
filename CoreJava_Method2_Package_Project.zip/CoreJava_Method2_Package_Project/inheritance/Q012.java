package inheritance;

class Q012Helper1 { Q012Helper1(String message){System.out.println("Parent constructor: "+message);} }
class Q012Helper2 extends Q012Helper1 { Q012Helper2(){super("called first");System.out.println("Child constructor");} }
public class Q012 { public static void main(String[] args){new Q012Helper2();} }
