package inheritance;

class Q014Helper1 { void sound(){System.out.println("Animal sound");} }
class Q014Helper2 extends Q014Helper1 { @Override void sound(){System.out.println("Woof");} }
class Q014Helper3 extends Q014Helper1 { @Override void sound(){System.out.println("Meow");} }
public class Q014 { public static void main(String[] args){Q014Helper1 a=new Q014Helper2();Q014Helper1 b=new Q014Helper3();a.sound();b.sound();} }
