package inheritance;

abstract class Q022Helper1 { abstract void eat(); abstract void exercise(); }
class Q022Helper2 extends Q022Helper1 { void eat(){System.out.println("Athlete eats a balanced diet");} void exercise(){System.out.println("Athlete trains daily");} }
class Q022Helper3 extends Q022Helper1 { void eat(){System.out.println("Lazy person eats snacks");} void exercise(){System.out.println("Lazy person rarely exercises");} }
public class Q022 { public static void main(String[] args){Q022Helper1[] p={new Q022Helper2(),new Q022Helper3()};for(Q022Helper1 x:p){x.eat();x.exercise();}} }
