package inheritance;

abstract class Q021Helper1 { abstract void startEngine(); abstract void stopEngine(); }
class Q021Helper2 extends Q021Helper1 { void startEngine(){System.out.println("Car engine starts");} void stopEngine(){System.out.println("Car engine stops");} }
class Q021Helper3 extends Q021Helper1 { void startEngine(){System.out.println("Motorcycle engine starts");} void stopEngine(){System.out.println("Motorcycle engine stops");} }
public class Q021 { public static void main(String[] args){Q021Helper1[] v={new Q021Helper2(),new Q021Helper3()};for(Q021Helper1 x:v){x.startEngine();x.stopEngine();}} }
