package inheritance;

abstract class Q025Helper1 { abstract void fly(); abstract void makeSound(); }
class Q025Helper2 extends Q025Helper1 { void fly(){System.out.println("Eagle soars high");} void makeSound(){System.out.println("Eagle chirps");} }
class Q025Helper3 extends Q025Helper1 { void fly(){System.out.println("Hawk glides");} void makeSound(){System.out.println("Hawk screeches");} }
public class Q025 { public static void main(String[] args){Q025Helper1[] b={new Q025Helper2(),new Q025Helper3()};for(Q025Helper1 x:b){x.fly();x.makeSound();}} }
