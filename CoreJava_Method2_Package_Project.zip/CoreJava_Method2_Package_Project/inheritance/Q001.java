package inheritance;

class Q001Helper1 { void makeSound() { System.out.println("Animal sound"); } }
class Q001Helper2 extends Q001Helper1 { @Override void makeSound() { System.out.println("Cat barks"); } }
public class Q001 { public static void main(String[] args) { new Q001Helper2().makeSound(); } }
