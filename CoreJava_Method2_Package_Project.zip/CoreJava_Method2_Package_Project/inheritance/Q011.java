package inheritance;

class Q011Helper1 { String name; Q011Helper1(String name){this.name=name;} }
class Q011Helper2 extends Q011Helper1 { int roll; Q011Helper2(String name,int roll){super(name);this.roll=roll;} void show(){System.out.println(super.name+" "+roll);} }
public class Q011 { public static void main(String[] args){new Q011Helper2("Aman",12).show();} }
