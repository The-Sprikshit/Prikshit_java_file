package inheritance;

class Q002Helper1 { void drive() { System.out.println("Vehicle is moving"); } }
class Q002Helper2 extends Q002Helper1 { @Override void drive() { System.out.println("Repairing a car"); } }
public class Q002 { public static void main(String[] args) { new Q002Helper2().drive(); } }
