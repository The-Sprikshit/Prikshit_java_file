CORE JAVA PRACTICE — METHOD 2 (PACKAGE COMMANDS)

Each topic has its own folder and matching Java package.
To run a question, open CMD in the project folder and enter the topic folder.

EXAMPLE — Arrays:
    cd arrays
    javac -d . Q001.java
    java arrays.Q001

EXAMPLE — Strings:
    cd strings
    javac -d . Q001.java
    java strings.Q001

EXAMPLE — Basic Programming:
    cd basicprogramming
    javac -d . Q001.java
    java basicprogramming.Q001

Replace Q001 with the question number you want (for example Q023).
The Java files already contain their package declaration.
The command javac -d . creates a package-named subfolder for compiled .class
files inside the current topic folder; this is expected for this command style.
Make sure the Java JDK is installed and javac works in CMD.

TOPIC FOLDERS:
    arrays/ — 23 question programs; package arrays
    basicprogramming/ — 139 question programs; package basicprogramming
    dataconversion/ — 30 question programs; package dataconversion
    exceptionhandling/ — 13 question programs; package exceptionhandling
    functions/ — 13 question programs; package functions
    inheritance/ — 26 question programs; package inheritance
    inputoutput/ — 10 question programs; package inputoutput
    interfaces/ — 11 question programs; package interfaces
    multidimensionalarrays/ — 13 question programs; package multidimensionalarrays
    multithreading/ — 13 question programs; package multithreading
    oop/ — 32 question programs; package oop
    packages/ — 10 question programs; package packages
    strings/ — 50 question programs; package strings
